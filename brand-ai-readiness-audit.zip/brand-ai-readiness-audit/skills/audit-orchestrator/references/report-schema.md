# Audit report schema

One report per audit.

## Required

| Field | Type | Notes |
| --- | --- | --- |
| `site` | string | Registrable domain, no scheme, no `www.` |
| `audited_at` | string | ISO 8601 UTC |
| `summary.total_findings` | int | Length of `findings` |
| `summary.critical/.high/.medium` | int | Must sum to `total_findings` |
| `findings[].id` | string | `F-001`, assigned after sorting |
| `findings[].title` | string | Names the defect, not the fix |
| `findings[].severity` | enum | critical \| high \| medium |
| `findings[].evidence` | string | Reproducible: counts, URLs, header values |
| `findings[].suggested_action.summary` | string | What to change |
| `findings[].suggested_action.priority` | enum | critical \| high \| medium |

## Extensions

| Field | Type | Purpose |
| --- | --- | --- |
| `findings[].check_id` | string | e.g. `D09`, `E04` |
| `findings[].skill` | string | Producing skill |
| `findings[].category` | enum | discoverability \| engagement |
| `findings[].mechanism` | string | Why this blocks an assistant, not just that it's wrong |
| `findings[].consequences` | array | Downstream checks suppressed by this finding |
| `findings[].suggested_action.detail/.effort/.verify` | string/enum/string | Concrete fix, effort, how to confirm |
| `proactive_actions` | array | Improvements where no defect was found |
| `coverage` | object | What was/wasn't established |

`mechanism` separates an audit from a lint: not "missing meta description" but
"extractors quote a page's summary sentence to judge relevance; with none
present it falls back to the first body text, here the cookie notice."

## Coverage object

`status`: `complete` | `partial` (skill failed) | `blocked` (crawler denied) |
`incomplete` (site unreachable). Fields: `pages_sampled`, `sampled_urls`,
`checks_run`, `checks_passed`, `unclear[{check_id,reason}]`,
`not_applicable[{check_id,reason}]`, `skills_failed`.

## Proactive action

`{id, title, rationale, priority, effort}` — carries `priority`, never `severity`.

## Worked example

```json
{
  "site": "example.com", "audited_at": "2026-09-20T14:32:00Z",
  "summary": { "total_findings": 1, "critical": 1, "high": 0, "medium": 0 },
  "findings": [{
    "id": "F-001", "check_id": "D09", "skill": "render-extractability",
    "category": "discoverability", "severity": "critical",
    "title": "Primary content is only present after JavaScript executes",
    "mechanism": "Assistants fetching a URL without a browser see the pre-hydration shell, so none of the page's substance is quotable.",
    "evidence": "Raw HTML visible text 412 chars vs rendered 18,344 (ratio 0.02) across 10 pages.",
    "consequences": [{ "check_id": "D10", "note": "No h1 in raw HTML; present rendered." }],
    "suggested_action": { "summary": "Server-render the main content region.",
      "priority": "critical", "effort": "high",
      "verify": "curl with no JS, confirm heading/body copy present." }
  }],
  "proactive_actions": [],
  "coverage": { "status": "complete", "pages_sampled": 10, "checks_run": 41,
    "checks_passed": 30, "unclear": [], "not_applicable": [], "skills_failed": [] }
}
```
