# Suppression and reconciliation rules

Findings aren't independent — one broken link makes downstream checks fail as
a side effect. Apply these after collecting raw findings, before assigning IDs.

## Recording

A suppressed finding is never deleted — it moves into the causing finding's
`consequences` array:
```json
{ "id": "F-001", "check_id": "D09", "severity": "critical",
  "consequences": [{ "check_id": "D10", "note": "No h1 in raw HTML — expected to resolve once server-rendered." }] }
```

## Rule 1 — Blocked access suppresses everything downstream
If `D02` or `D04` fails, no other check describes what an assistant would
actually see: emit the access finding critical, mark every other check
`unclear`, `coverage.status = "blocked"`. `D03` alone does not trigger this —
the rest of the site is still readable.

## Rule 2 — A render gap suppresses raw-HTML-derived findings
If `D09` fails, re-evaluate `D10`, `D11`, `D15`, `D16`, `D18`, `D19`, `D21`,
`D23` against the rendered DOM. Passes there -> consequence of D09. Fails
there too -> real independent finding. The single most important rule — a
client-rendered site trips 5-8 checks for one root cause.

## Rule 3 — Absence upstream makes downstream checks n/a, not fail
| If this failed | These become `n/a` |
| --- | --- |
| D05 no sitemap | D06 sitemap freshness |
| D16 no JSON-LD | D17, D19, D20, D23, D26 |
| D01 no robots.txt | D02, D03 (treat as permissive) |

## Rule 4 — Site-type gating
| Check | `n/a` when |
| --- | --- |
| E05 pricing reachable | Nonprofit/reference/gov/edu, no commercial offering |
| D18 Product schema | No product/commerce routes |
| D26 visible dates | No time-sensitive content |
| E12 FAQ coverage | Single-purpose landing page |

## Rule 5 — Proactive checks never become findings
`D28` (llms.txt) and anything marked `proactive: true` go in
`proactive_actions` only, never `findings`, never a severity.

## Rule 6 — Collapse per-page repeats
One finding with a count + up to 3 example URLs, not one per page:
`9/10 sampled pages lack a meta description; e.g. /about, /pricing, /careers`.

## Rule 7 — Deterministic ordering
Sort by severity (critical, high, medium), then check ID ascending. Assign
`F-001` upward after sorting.
