---
name: audit-orchestrator
description: >
  Entrypoint for the brand-ai-readiness-audit marketplace. Given a website URL
  or domain, crawls a representative sample of the site once, delegates to the
  four diagnostic skills (crawl-access-audit, render-extractability,
  structured-data-audit, entity-corroboration) and to engagement-audit,
  de-duplicates cascading findings, and emits a single structured audit report
  of problems plus prioritized suggested actions. Use for "why doesn't this
  brand show up / get cited / get engagement" and AI-readiness / GEO audits.
license: MIT
allowed-tools: Bash, Read, Write, WebFetch, WebSearch
---

# Brand AI-Readiness Audit — orchestrator

Recommend-only. Do not use this skill to change a website.

## Inputs

| Input | Required | Default |
| --- | --- | --- |
| `url` | yes | a URL or bare domain, e.g. `example.com` |
| `brand_name` | no | inferred from `<title>` or Organization schema |
| `sample_size` | no | `10` pages |
| `max_runtime` | no | `300` seconds |

## Why order matters

Access -> render -> extract -> corroborate is a dependency chain; engagement is
parallel. Running diagnostics in that order is what makes de-duplication
possible: when an earlier link breaks, later checks fail as a *consequence*,
not as separate findings.

## Procedure

1. **Normalise the target.** Resolve bare domains via `https://`, follow
   redirects, record the final host. Treat `host` and `www.host` as the same site.
2. **Build the shared crawl bundle once:**
   `scripts/fetch_bundle.py <url> --out bundle.json --sample <n>`.
   This is the only network crawl; every downstream skill reads `bundle.json`.
   Respect `robots.txt`, rate-limit to 1 req/s, no credentials, no login pages.
   If the homepage can't be fetched, stop and emit a report with
   `status: "incomplete"` — don't guess the rest.
3. **Run the diagnostic skills**, each against `bundle.json`:
   1. `crawl-access-audit` — is the crawler let in?
   2. `render-extractability` — can a machine read what's there?
   3. `structured-data-audit` — can it lift a clean, attributable fact?
   4. `entity-corroboration` — is that fact attached to the right entity and believed?
   5. `engagement-audit` — does the visitor who arrives stay?
   1-4 may run in any order among themselves; reconcile in the order above.
4. **Reconcile and suppress** per `references/suppression-rules.md` before
   assembling the report — precision over volume.
5. **Assign severity** from each skill's check table (don't re-judge per site):
   - **critical** — the fact can't get out at all (blocked crawler, JS-only content, fact locked in an image, contradicting structured data).
   - **high** — reachable but not extractable as a clean fact (no schema, ambiguous entity, uncorroborated claim, no stated offering).
   - **medium** — fact gets out; discoverability/engagement is degraded.
   Downgrade one tier on `partial`. Never emit a finding for `pass`/`n/a`/`unclear` — `unclear` goes in `coverage.unclear`.
6. **Add 2-5 proactive_actions** from `references/proactive-playbook.md`, filtered to what actually fits this site (check the bundle first — don't recommend what's already done).
7. **Emit the report:**
   `scripts/assemble_report.py --findings <files> --bundle bundle.json --out report.json`.
   Validate against `references/report-schema.md`. Exactly one report. Record any skill that failed to run under `coverage.skills_failed`.

## Output

A single JSON document (schema: `references/report-schema.md`) with `site`,
`audited_at`, `summary`, `findings[]` (each with `id`, `check_id`, `severity`,
`evidence`, `suggested_action`), `proactive_actions`, `coverage`.

Evidence must be reproducible: a header value, a count, a quoted `robots.txt`
line — not "poor structured data" but "0 of 12 sampled product pages contain
`<script type=application/ld+json>`".

## Guardrails

Recommend-only, read-only, sandboxed, 1 req/s, `robots.txt` respected, sample
caps total fetches, deterministic output for the same site+sample.
