import argparse
import json
import sys

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2}
DOWNGRADE = {"critical": "high", "high": "medium", "medium": "medium"}

BLOCKING = {"D02", "D04"}

# Advisory: the checks a skill should re-evaluate against the rendered DOM when D09
# fails. Folding is driven by the `passes_on_rendered_dom` flag the producing skill
# sets, not by this set — a skill that adds a render-dependent check does not have to
# remember to edit this file.
RENDER_DEPENDENT = {"D10", "D11", "D12", "D13", "D14", "D15", "D16", "D18", "D19", "D21", "D23"}
REQUIRES = {"D06": "D05", "D17": "D16", "D19": "D16", "D20": "D16", "D23": "D16", "D26": "D16",
            "D02": "D01", "D03": "D01"}
PROACTIVE_ONLY = {"D28"}


def load(paths):
    out = []
    for p in paths:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        out.extend(d if isinstance(d, list) else d.get("findings", []))
    return out


def finalize(findings):
    findings.sort(key=lambda f: (SEVERITY_ORDER.get(f["severity"], 9), f["check_id"]))
    for n, f in enumerate(findings, 1):
        f["id"] = f"F-{n:03d}"
        for k in ("result", "result_detail", "passes_on_rendered_dom"):
            f.pop(k, None)
    return findings


def reconcile(raw, bundle):
    by_check = {f["check_id"]: f for f in raw if f.get("result") == "fail"}
    coverage = {"unclear": [], "not_applicable": [], "suppressed": []}
    kept, consequences = [], {}

    blocked = sorted(c for c in BLOCKING if c in by_check)
    if blocked:
        root = by_check[blocked[0]]
        root["severity"] = "critical"
        for f in raw:
            if f["check_id"] != root["check_id"]:
                coverage["unclear"].append({"check_id": f["check_id"],
                                            "reason": "Crawler access denied; other results are not representative."})
        return finalize([root]), coverage, "blocked"

    render_gap = by_check.get("D09")
    for f in raw:
        cid = f["check_id"]
        if f.get("result") != "fail":
            if f.get("result") == "unclear":
                coverage["unclear"].append({"check_id": cid, "reason": f.get("evidence", "")})
            elif f.get("result") == "n/a":
                coverage["not_applicable"].append({"check_id": cid, "reason": f.get("evidence", "")})
            continue

        if cid in PROACTIVE_ONLY:
            coverage["suppressed"].append({"check_id": cid, "reason": "Proactive opportunity, not a defect."})
            continue

        parent = REQUIRES.get(cid)
        if parent and parent in by_check:
            consequences.setdefault(parent, []).append(
                {"check_id": cid, "note": f"Not independently reportable: {parent} already reports the absence."})
            continue

        if render_gap and f.get("passes_on_rendered_dom"):
            consequences.setdefault("D09", []).append(
                {"check_id": cid, "note": "Fails on raw HTML, passes on rendered DOM — consequence of the render gap."})
            continue

        if f.get("result_detail") == "partial":
            f["severity"] = DOWNGRADE.get(f["severity"], f["severity"])
        kept.append(f)

    for f in kept:
        if f["check_id"] in consequences:
            f["consequences"] = consequences[f["check_id"]]

    return finalize(kept), coverage, bundle.get("status", "complete")


def main():
    ap = argparse.ArgumentParser(description="Assemble the final audit report.")
    ap.add_argument("--findings", nargs="+", required=True)
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--proactive", default=None)
    ap.add_argument("--out", default="report.json")
    a = ap.parse_args()

    with open(a.bundle, encoding="utf-8") as f:
        bundle = json.load(f)
    raw = load(a.findings)
    findings, coverage, status = reconcile(raw, bundle)

    proactive = []
    if a.proactive:
        with open(a.proactive, encoding="utf-8") as f:
            proactive = json.load(f)
    for n, p in enumerate(proactive, 1):
        p["id"] = f"P-{n:03d}"

    counts = {s: sum(1 for f in findings if f["severity"] == s) for s in SEVERITY_ORDER}
    report = {
        "site": bundle.get("site", bundle.get("input")),
        "audited_at": bundle.get("audited_at"),
        "summary": {"total_findings": len(findings), **counts},
        "findings": findings,
        "proactive_actions": proactive,
        "coverage": {
            "status": status,
            "pages_sampled": len(bundle.get("pages", [])),
            "sampled_urls": [p.get("final_url", p.get("requested_url")) for p in bundle.get("pages", [])],
            "checks_run": len(raw),
            "checks_passed": sum(1 for f in raw if f.get("result") == "pass"),
            "unclear": coverage["unclear"],
            "not_applicable": coverage["not_applicable"],
            "skills_failed": bundle.get("errors", []),
        },
    }

    assert report["summary"]["total_findings"] == sum(counts.values()), "severity counts must sum to total"
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    print(json.dumps(report["summary"], indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
