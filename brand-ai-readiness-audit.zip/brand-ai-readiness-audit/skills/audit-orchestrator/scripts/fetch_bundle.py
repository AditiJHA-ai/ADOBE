import argparse
import json
import re
import sys
import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
PLAIN_UA = "BrandAIReadinessAudit/1.0 (+recommend-only; respects robots.txt)"
AI_AGENTS = ["gptbot", "oai-searchbot", "chatgpt-user", "claudebot", "anthropic-ai",
             "perplexitybot", "google-extended", "ccbot", "bingbot"]
DELAY = 1.0
TIMEOUT = 25


def norm_host(netloc):
    return netloc.lower().split(":")[0].removeprefix("www.")


def get(url, ua=BROWSER_UA):
    time.sleep(DELAY)
    return requests.get(url, headers={"User-Agent": ua}, timeout=TIMEOUT, allow_redirects=True)


def robots_groups(text):
    groups, current, prev_agent = {}, [], False
    for raw in text.splitlines():
        line = raw.split("#")[0].strip()
        if not line or ":" not in line:
            continue
        k, v = line.split(":", 1)
        k, v = k.strip().lower(), v.strip()
        if k == "user-agent":
            if not prev_agent:
                current = []
            current.append(v.lower())
            groups.setdefault(v.lower(), [])
            prev_agent = True
            continue
        prev_agent = False
        if k in ("disallow", "allow"):
            for a in current:
                groups[a].append([k, v])
        elif k == "sitemap":
            groups.setdefault("__sitemaps__", []).append(v)
    return groups


def visible_text(html):
    soup = BeautifulSoup(html, "html.parser")
    for t in soup(["script", "style", "noscript", "template", "svg"]):
        t.decompose()
    return re.sub(r"\s+", " ", soup.get_text(" ")).strip()


def collect_sitemap(base, groups):
    urls, dates, seen = [], [], set()
    cands = list(groups.get("__sitemaps__", []))
    cands += [urljoin(base, "/sitemap.xml"), urljoin(base, "/sitemap_index.xml")]
    while cands and len(urls) < 5000:
        sm = cands.pop(0)
        if sm in seen or len(seen) > 6:
            continue
        seen.add(sm)
        try:
            r = get(sm)
        except requests.RequestException:
            continue
        if r.status_code != 200 or "<" not in r.text:
            continue
        soup = BeautifulSoup(r.text, "xml")
        if soup.find("sitemapindex"):
            cands += [loc.get_text(strip=True) for loc in soup.find_all("loc")[:3]]
            continue
        for u in soup.find_all("url"):
            loc = u.find("loc")
            if loc is None:
                continue
            urls.append(loc.get_text(strip=True))
            lm = u.find("lastmod")
            dates.append(lm.get_text(strip=True) if lm else None)
    return urls, dates, sorted(seen)


OVERLAY_JS = """() => {
    const vw = innerWidth, vh = innerHeight;
    return [...document.querySelectorAll('body *')].filter(e => {
        const s = getComputedStyle(e);
        if (s.position !== 'fixed') return false;
        if (s.display === 'none' || s.visibility === 'hidden' || +s.opacity === 0) return false;
        const r = e.getBoundingClientRect();
        return r.width * r.height > vw * vh * 0.4 && +s.zIndex > 100;
    }).length;
}"""

ABOVE_FOLD_JS = """() => {
    const vh = innerHeight;
    const inFold = e => { const r = e.getBoundingClientRect(); return r.top < vh && r.bottom > 0 && r.width > 0; };
    const txt = [...document.querySelectorAll('h1,h2,h3,p,li,span')]
        .filter(inFold).map(e => e.innerText.trim()).filter(Boolean).join(' ');
    const actions = [...document.querySelectorAll('a,button,input[type=submit]')]
        .filter(inFold).filter(e => e.innerText.trim() || e.value)
        .map(e => (e.innerText || e.value).trim()).filter(t => t.length < 60);
    return { text: txt.slice(0, 4000), actions: actions.slice(0, 40) };
}"""


def render_pages(urls, full_url):
    """Render every sampled page in one browser session.

    Per-page rendering is what makes D09 decidable page by page rather than
    extrapolated from the homepage; the heavier probes (no-JS, weight, overlay,
    mobile) run once on the homepage, where they are representative enough and
    where paying for them ten times would not fit the runtime budget.
    """
    from playwright.sync_api import sync_playwright
    pages, site = {}, {"bytes": 0, "requests": 0, "overlay_count": None,
                       "mobile_overflow": None, "nojs_html": "", "render_error": None}
    with sync_playwright() as p:
        b = p.chromium.launch()
        try:
            ctx = b.new_context(viewport={"width": 1280, "height": 900}, user_agent=BROWSER_UA)
            for u in urls:
                pg = ctx.new_page()
                rec = {"rendered_html": "", "above_fold": None, "error": None}
                if u == full_url:
                    def on_response(resp):
                        site["requests"] += 1
                        try:
                            site["bytes"] += int(resp.headers.get("content-length", 0))
                        except (TypeError, ValueError):
                            pass
                    pg.on("response", on_response)
                try:
                    pg.goto(u, wait_until="networkidle", timeout=45000)
                    rec["rendered_html"] = pg.content()
                    if u == full_url:
                        rec["above_fold"] = pg.evaluate(ABOVE_FOLD_JS)
                        site["overlay_count"] = pg.evaluate(OVERLAY_JS)
                        pg.set_viewport_size({"width": 390, "height": 844})
                        site["mobile_overflow"] = bool(pg.evaluate("document.documentElement.scrollWidth > 400"))
                except Exception as e:
                    rec["error"] = f"{type(e).__name__}: {e}"
                finally:
                    pages[u] = rec
                    pg.close()
            ctx2 = b.new_context(java_script_enabled=False, user_agent=BROWSER_UA)
            pg2 = ctx2.new_page()
            try:
                pg2.goto(full_url, wait_until="domcontentloaded", timeout=30000)
                site["nojs_html"] = pg2.content()
            except Exception as e:
                site["nojs_error"] = f"{type(e).__name__}: {e}"
        except Exception as e:
            site["render_error"] = f"{type(e).__name__}: {e}"
        finally:
            b.close()
    return pages, site


def build(url, sample_size):
    base = url if url.startswith("http") else "https://" + url
    bundle = {"input": url, "audited_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "status": "complete", "pages": [], "errors": []}

    try:
        home = get(base)
    except requests.RequestException as e:
        bundle["status"] = "incomplete"
        bundle["errors"].append(f"homepage unreachable: {type(e).__name__}: {e}")
        return bundle

    final = home.url
    host = norm_host(urlparse(final).netloc)
    bundle["site"] = host
    bundle["base_url"] = final
    bundle["homepage_status"] = home.status_code

    try:
        plain = get(base, ua=PLAIN_UA)
        bundle["plain_ua_status"] = plain.status_code
    except requests.RequestException as e:
        bundle["plain_ua_status"] = None
        bundle["errors"].append(f"plain-UA probe failed: {type(e).__name__}")
    bundle["browser_ua_status"] = home.status_code

    try:
        rb = get(urljoin(final, "/robots.txt"))
        bundle["robots"] = {"status": rb.status_code, "body": rb.text if rb.status_code == 200 else ""}
    except requests.RequestException as e:
        bundle["robots"] = {"status": None, "body": "", "error": str(e)}
    groups = robots_groups(bundle["robots"]["body"])
    bundle["robots"]["groups"] = groups
    bundle["robots"]["ai_agents_present"] = [a for a in AI_AGENTS if a in groups]

    sm_urls, sm_dates, sm_sources = collect_sitemap(final, groups)
    bundle["sitemap"] = {"sources": sm_sources, "declared_in_robots": bool(groups.get("__sitemaps__")),
                         "url_count": len(sm_urls), "lastmods": sm_dates[:5000]}

    same_host = [u for u in sm_urls if norm_host(urlparse(u).netloc) == host]
    seen, sample = {final}, [final]
    for u in same_host:
        if len(sample) >= sample_size:
            break
        if u not in seen:
            seen.add(u)
            sample.append(u)

    for u in sample:
        page = {"requested_url": u}
        try:
            r = get(u)
        except requests.RequestException as e:
            page["error"] = f"{type(e).__name__}: {e}"
            bundle["pages"].append(page)
            continue
        page.update({
            "final_url": r.url,
            "status": r.status_code,
            "redirect_hops": len(r.history),
            "headers": {k: v for k, v in r.headers.items()},
            "raw_html": r.text,
            "raw_text_len": len(visible_text(r.text)),
        })
        bundle["pages"].append(page)

    fetched = [p["final_url"] for p in bundle["pages"] if p.get("status") == 200]
    try:
        rendered, site_render = render_pages(fetched, final)
        for p in bundle["pages"]:
            rec = rendered.get(p.get("final_url"), {})
            p["rendered_html"] = rec.get("rendered_html", "")
            p["rendered_text_len"] = len(visible_text(rec["rendered_html"])) if rec.get("rendered_html") else 0
            p["render_error"] = rec.get("error")
            if rec.get("above_fold"):
                p["above_fold"] = rec["above_fold"]
        bundle["render"] = site_render
        bundle["render"]["nojs_text_len"] = len(visible_text(site_render["nojs_html"])) if site_render.get("nojs_html") else 0
    except Exception as e:
        bundle["render"] = {"render_error": f"{type(e).__name__}: {e}"}
        bundle["errors"].append("render stage failed; render-dependent checks will be unclear")

    try:
        lt = get(urljoin(final, "/llms.txt"))
        bundle["llms_txt"] = {"status": lt.status_code, "bytes": len(lt.text)}
    except requests.RequestException:
        bundle["llms_txt"] = {"status": None, "bytes": 0}

    if not any(p.get("status") == 200 for p in bundle["pages"]):
        bundle["status"] = "incomplete"
    return bundle


def main():
    ap = argparse.ArgumentParser(description="Fetch the shared crawl bundle for one site.")
    ap.add_argument("url")
    ap.add_argument("--out", default="bundle.json")
    ap.add_argument("--sample", type=int, default=10)
    a = ap.parse_args()
    bundle = build(a.url, a.sample)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(bundle, f, ensure_ascii=False)
    print(json.dumps({"site": bundle.get("site"), "status": bundle["status"],
                      "pages": len(bundle["pages"]), "out": a.out,
                      "errors": bundle["errors"]}, indent=2))
    return 0 if bundle["status"] != "incomplete" else 1


if __name__ == "__main__":
    sys.exit(main())
