# Access checks — detection, thresholds, rationale

Thresholds are calibrated so a healthy site passes; a check that fires on
healthy sites costs more than the defect it catches.

## D01 — robots.txt exists and is fetchable
**Detect:** `GET /robots.txt`. **Fail:** 4xx/5xx. **Pass:** 200.
Absence is *permissive* (medium, not critical) — but it means no place to
declare a sitemap or selectively grant AI crawler access.
**Fix:** publish one with a `Sitemap:` line even if it allows everything.

## D02 — Generic crawlers allowed on content paths
**Detect:** parse the `User-agent: *` group against main content path prefixes.
**Fail:** `Disallow: /` or a prefix covering main content routes.
Exclude `/cart`, `/checkout`, `/account`, `/admin`, `/login`, `/search`, `/api`,
`/wp-admin`, `/cgi-bin`, session/query-param paths — blocking these is correct.
This is the front door: a D02 failure suppresses every other finding.
**Fix:** scope `Disallow` to transactional routes only.

## D03 — Named AI crawlers not blocked
**Detect:** per-agent groups for `GPTBot`, `OAI-SearchBot`, `ChatGPT-User`,
`ClaudeBot`, `anthropic-ai`, `PerplexityBot`, `Google-Extended`, `CCBot`.
Robots.txt allows stacked `User-agent:` lines sharing one rule — parse groups,
not adjacent lines. **Fail:** 2+ agents `Disallow: /`. **Partial:** exactly one.
Note: `Google-Extended`/`CCBot` govern training opt-out; `GPTBot`/`ClaudeBot`
govern retrieval — a brand may want one blocked and not the other.
**Fix:** remove `Disallow: /` from retrieval agents; scope like `*`.

## D04 — Plain user-agent not blocked while browsers pass
**Detect:** fetch homepage with a plain UA and a browser UA; compare status.
**Fail:** plain UA gets 403/429/503, browser UA gets 200. Most commonly missed
cause of total AI invisibility — leaves no trace in robots.txt.
**Fix:** allowlist documented AI crawler UAs/IP ranges at the CDN/WAF.

## D05 — Sitemap exists and declared in robots.txt
**Detect:** `Sitemap:` lines, else probe `/sitemap.xml`, `/sitemap_index.xml`.
**Fail:** none found. **Partial:** reachable but undeclared.
**Fix:** generate, declare in robots.txt, include `lastmod`.

## D06 — Sitemap lastmod dates current
**Detect:** share of URLs with `lastmod` within 12 months. **N/A:** no sitemap
(D05). **Fail:** <25% or none. **Partial:** 25-60%. **Pass:** >60%.
**Fix:** emit real `lastmod` from the CMS; don't stamp every URL with today's date.

## D07 — Content pages return 200 without long redirect chains
**Detect:** status + redirect hop count on sampled URLs.
**Fail:** >20% non-200, or any chain >2 hops.
**Fix:** regenerate sitemap from live routes; collapse redirect chains.

## D08 — No noindex/nosnippet/max-snippet:0 on content pages
**Detect:** `meta[name=robots]` AND `X-Robots-Tag` header (check both — header
is easy to set globally and forget). **Fail:** any content page carries them.
`nosnippet`/`max-snippet:0` are subtler than `noindex`: page stays indexed but
nothing may be quoted — found but uncitable.
**Fix:** remove from content routes; keep on thank-you/search/paginated pages.

## Calibration
- Normalise hosts before comparing (`example.com` == `www.example.com`) —
  otherwise false off-domain findings on canonical/sitemap/link checks.
- Absence is one finding, not many: no sitemap must not also fire as stale
  dates; no robots.txt must not also fire as blocked crawlers.
