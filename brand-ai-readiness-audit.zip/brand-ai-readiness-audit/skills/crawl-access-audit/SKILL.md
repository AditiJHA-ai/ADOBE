---
name: crawl-access-audit
description: >
  Determines whether an automated reader is allowed to reach a site's content
  at all — robots.txt directives for generic and AI-specific crawlers,
  user-agent discrimination, sitemap presence/freshness, HTTP status/redirect
  health, noindex/nosnippet. Use as the first diagnostic stage of a brand
  AI-readiness audit, or standalone when a site is entirely absent from AI
  assistants and search.
license: MIT
allowed-tools: Bash, Read
---

# Crawl access audit

First stage of `brand-ai-readiness-audit`. Nothing downstream matters if this
fails — a page a crawler can't fetch has an access problem, not a content problem.

## Input

`bundle.json` from `audit-orchestrator/scripts/fetch_bundle.py`. No network
requests of its own.

## Procedure

Run `scripts/check_access.py --bundle bundle.json --out access-findings.json`
(checks `D01`-`D08`; detection/threshold/rationale in `references/checks.md`).

Then judge two things the script can't:
1. **Intent** — `Disallow` on `/cart/`, `/account/`, `/search/`, `/admin/` is
   correct practice, not a defect (already excluded; mark unusual equivalents `n/a`).
2. **Site type** — a staging/private/paywalled site may block crawlers deliberately; say so.

## Checks

| ID | Check | Severity | Notes |
| --- | --- | --- | --- |
| D01 | robots.txt exists and is fetchable | medium | Absence is permissive, not fatal |
| D02 | Generic crawlers allowed on content paths | critical | Triggers global suppression |
| D03 | Named AI crawlers not blocked | critical | GPTBot, ClaudeBot, PerplexityBot, Google-Extended, CCBot, OAI-SearchBot |
| D04 | Plain user-agent not blocked while browsers pass | critical | Triggers global suppression |
| D05 | Sitemap exists and declared in robots.txt | medium | — |
| D06 | Sitemap lastmod dates current | medium | `n/a` when D05 found no sitemap |
| D07 | Content pages 200 without long redirect chains | high | — |
| D08 | No noindex/nosnippet/max-snippet:0 on content pages | critical | — |

## Output

JSON array of finding records: `check_id`, `result` (pass/fail/partial/n/a/unclear),
`severity`, `category`, `mechanism`, `evidence`, `suggested_action`. Orchestrator
reconciles/suppresses/numbers — this skill doesn't. Evidence must quote the
observation (e.g. actual robots.txt directive lines).

## Guardrails

Read-only, no network access. Never recommend removing a `Disallow` that
protects a transactional/authenticated/private area.
