import argparse
import json
import re
import sys
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse

AI_RETRIEVAL = ["gptbot", "oai-searchbot", "chatgpt-user", "claudebot", "anthropic-ai", "perplexitybot"]
AI_TRAINING = ["google-extended", "ccbot"]
TRANSACTIONAL = ("/cart", "/checkout", "/account", "/admin", "/login", "/signin", "/search",
                 "/api", "/wp-admin", "/cgi-bin", "/basket", "/my-account", "/user")


TITLES = {
    "D01": "No robots.txt published",
    "D02": "robots.txt disallows generic crawlers on content paths",
    "D03": "robots.txt blocks AI retrieval crawlers",
    "D04": "Site returns an error to non-browser user-agents",
    "D05": "No sitemap published or declared",
    "D06": "Sitemap lastmod dates are stale or absent",
    "D07": "Sampled URLs return errors or long redirect chains",
    "D08": "Content pages carry noindex or nosnippet directives",
}


def finding(cid, result, severity, evidence, mechanism="", summary="", detail="",
            effort="medium", verify="", detail_result=None):
    return {"check_id": cid, "skill": "crawl-access-audit", "category": "discoverability",
            "title": TITLES[cid],
            "result": result, "result_detail": detail_result, "severity": severity,
            "mechanism": mechanism, "evidence": evidence,
            "suggested_action": {"summary": summary, "detail": detail,
                                 "priority": severity, "effort": effort, "verify": verify}}


def content_prefixes(bundle):
    out = set()
    for p in bundle.get("pages", []):
        path = urlparse(p.get("final_url") or p.get("requested_url", "")).path
        seg = "/" + path.strip("/").split("/")[0] if path.strip("/") else "/"
        if not seg.startswith(TRANSACTIONAL):
            out.add(seg)
    return out or {"/"}


def aware(d):
    return d if d is None or d.tzinfo else d.replace(tzinfo=timezone.utc)


def parse_date(s):
    if not s:
        return None
    try:
        return aware(datetime.fromisoformat(s.replace("Z", "+00:00")))
    except ValueError:
        for fmt, n in (("%Y-%m-%d", 10), ("%Y-%m", 7), ("%Y", 4)):
            try:
                return datetime.strptime(s[:n], fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
    return None


def d01(b):
    r = b.get("robots", {})
    if r.get("status") == 200:
        return finding("D01", "pass", "medium", f"GET /robots.txt -> 200, {len(r.get('body',''))} bytes")
    if r.get("status") is None:
        return finding("D01", "unclear", "medium", f"/robots.txt fetch failed: {r.get('error','unknown error')}")
    return finding(
        "D01", "fail", "medium", f"GET /robots.txt -> {r['status']}",
        mechanism="An absent robots.txt is permissive, so crawlers are not blocked, but the site has no place to declare its sitemap or to grant AI crawlers access selectively.",
        summary="Publish a robots.txt that declares the sitemap.",
        detail="Serve /robots.txt with an explicit Sitemap: line. Allow all by default and scope Disallow rules to transactional routes only.",
        effort="low", verify="curl -sI https://<host>/robots.txt returns 200.")


def d02(b, prefixes):
    g = b.get("robots", {}).get("groups", {})
    if not g:
        return finding("D02", "n/a", "critical", "No robots.txt present; crawlers treat this as full allow.")
    star = g.get("*", [])
    dis = [p for k, p in star if k == "disallow" and p]
    blocking = [p for p in dis if p == "/" or any(pref.startswith(p.rstrip("*$")) for pref in prefixes)]
    blocking = [p for p in blocking if not p.startswith(TRANSACTIONAL)]
    if blocking:
        return finding(
            "D02", "fail", "critical",
            f"User-agent: * carries Disallow: {blocking[0]!r}, which covers content paths {sorted(prefixes)[:3]}",
            mechanism="This is the front door. If generic crawlers are turned away, nothing else about the site is observable to an automated reader.",
            summary="Scope the Disallow rules to transactional routes only.",
            detail="Replace the broad Disallow with explicit rules for /cart, /checkout, /account, /admin and /search. Leave content routes open.",
            effort="low", verify="Test the content paths against the * group in Search Console's robots.txt tester.")
    return finding("D02", "pass", "critical",
                   f"User-agent: * has {len(dis)} Disallow rules, none covering content paths {sorted(prefixes)[:3]}")


def d03(b):
    g = b.get("robots", {}).get("groups", {})
    if not g:
        return finding("D03", "n/a", "critical", "No robots.txt present; AI crawlers inherit full allow.")
    blocked_r = [a for a in AI_RETRIEVAL if any(k == "disallow" and p == "/" for k, p in g.get(a, []))]
    blocked_t = [a for a in AI_TRAINING if any(k == "disallow" and p == "/" for k, p in g.get(a, []))]
    named = b.get("robots", {}).get("ai_agents_present", [])
    if len(blocked_r) >= 2:
        res, det = "fail", None
    elif len(blocked_r) == 1:
        res, det = "fail", "partial"
    else:
        res, det = "pass", None
    if res == "pass":
        note = f"; training agents blocked: {blocked_t}" if blocked_t else ""
        return finding("D03", "pass", "critical",
                       f"Named AI agents in robots.txt: {named or 'none'}; no retrieval agent fully disallowed{note}")
    return finding(
        "D03", res, "critical",
        f"robots.txt Disallow: / for retrieval agents {blocked_r}" + (f"; training agents also blocked: {blocked_t}" if blocked_t else ""),
        mechanism="These agents fetch pages when a user asks an assistant a question. Blocking them removes the site from the candidate pool regardless of content quality. Retrieval agents (GPTBot, ClaudeBot, PerplexityBot) are distinct from training agents (Google-Extended, CCBot) — a brand may intend to block the latter only.",
        summary="Allow the retrieval agents on content routes.",
        detail=f"Remove Disallow: / from {', '.join(blocked_r)} and scope them to the same transactional routes as User-agent: *. If the training opt-out was intentional, leave Google-Extended and CCBot as they are.",
        effort="low", verify="Re-fetch robots.txt and confirm the retrieval agents no longer carry Disallow: /.",
        detail_result=det)


def d04(b):
    plain, brow = b.get("plain_ua_status"), b.get("browser_ua_status")
    if plain is None:
        return finding("D04", "unclear", "critical", "Plain user-agent probe did not complete.")
    if plain != brow and plain in (401, 403, 405, 406, 429, 503):
        return finding(
            "D04", "fail", "critical",
            f"Homepage returns {plain} to a plain user-agent but {brow} to a browser user-agent",
            mechanism="Bot-protection and WAF rules reject requests without a browser fingerprint. The site looks healthy to its owner and is invisible to every automated reader, leaving no trace in robots.txt.",
            summary="Allowlist documented AI crawler user-agents at the CDN or WAF.",
            detail="Add the published user-agent strings and IP ranges for GPTBot, ClaudeBot, PerplexityBot and OAI-SearchBot to the bot-management allowlist. Verify the rule applies to content routes, not just the homepage.",
            effort="medium", verify="curl -A 'GPTBot' https://<host>/ returns 200 with the full HTML body.")
    return finding("D04", "pass", "critical", f"plain user-agent -> {plain}, browser user-agent -> {brow}")


def d05(b):
    sm = b.get("sitemap", {})
    n, declared = sm.get("url_count", 0), sm.get("declared_in_robots")
    if not n:
        return finding(
            "D05", "fail", "medium",
            "No sitemap found via robots.txt Sitemap:, /sitemap.xml or /sitemap_index.xml",
            mechanism="Sitemaps are how crawlers find pages not reachable from the homepage in a shallow crawl. Without one, deep or orphaned content is never discovered.",
            summary="Publish a sitemap and declare it in robots.txt.",
            detail="Generate sitemap.xml from live routes with real lastmod values, and add a Sitemap: line to robots.txt.",
            effort="low", verify="curl https://<host>/sitemap.xml returns XML listing the content routes.")
    if not declared:
        return finding(
            "D05", "fail", "medium", f"Sitemap reachable ({n} URLs) but no Sitemap: line in robots.txt",
            mechanism="Crawlers that do not guess conventional filenames rely on the robots.txt declaration to find the sitemap.",
            summary="Add a Sitemap: line to robots.txt.",
            detail=f"Append `Sitemap: {sm.get('sources',[''])[0]}` to robots.txt.",
            effort="low", verify="robots.txt contains a Sitemap: line resolving to 200.",
            detail_result="partial")
    return finding("D05", "pass", "medium", f"Sitemap declared in robots.txt, {n} URLs across {len(sm.get('sources',[]))} file(s)")


def d06(b):
    sm = b.get("sitemap", {})
    if not sm.get("url_count"):
        return finding("D06", "n/a", "medium", "No sitemap present; freshness reported under D05.")
    dates = [parse_date(d) for d in sm.get("lastmods", []) if d]
    if not dates:
        return finding(
            "D06", "fail", "medium", f"0 of {sm['url_count']} sitemap URLs carry a lastmod element",
            mechanism="Retrieval systems weight recency and use lastmod to schedule re-crawls. With none present, fresh content is fetched late or not at all.",
            summary="Emit real lastmod values from the CMS.",
            detail="Populate lastmod per URL from the content's actual modification time. Do not stamp every URL with the same date — sitemaps whose dates move together are discounted.",
            effort="medium", verify="Sample 10 sitemap entries and confirm lastmod matches the page's real last edit.")
    cutoff = datetime.now(timezone.utc) - timedelta(days=365)
    recent = sum(1 for d in dates if d and d > cutoff)
    share = recent / len(dates)
    ev = f"{recent}/{len(dates)} lastmod dates within 12 months ({share:.0%})"
    if share > 0.60:
        return finding("D06", "pass", "medium", ev)
    return finding(
        "D06", "fail", "medium", ev,
        mechanism="A sitemap where most dates are over a year old signals an abandoned site and depresses re-crawl frequency.",
        summary="Refresh stale content or correct the lastmod values.",
        detail="Identify whether the dates are wrong or the content is genuinely stale. If the CMS is emitting build dates rather than edit dates, fix the generator.",
        effort="medium", verify="Re-check the share of sitemap URLs with lastmod inside 12 months.",
        detail_result="partial" if share >= 0.25 else None)


def d07(b):
    pages = b.get("pages", [])
    if not pages:
        return finding("D07", "unclear", "high", "No pages were fetched.")
    bad = [f"{p.get('requested_url')} -> {p.get('status', p.get('error','error'))}"
           for p in pages if p.get("status") != 200]
    hops = [f"{p.get('requested_url')} -> {p['redirect_hops']} hops"
            for p in pages if p.get("redirect_hops", 0) > 2]
    if len(bad) > len(pages) * 0.2 or hops:
        return finding(
            "D07", "fail", "high",
            f"{len(bad)}/{len(pages)} sampled URLs non-200" +
            (f"; {len(hops)} with chains over 2 hops" if hops else "") +
            "; e.g. " + "; ".join((bad + hops)[:3]),
            mechanism="Broken or heavily redirected sitemap URLs waste crawl budget and indicate the sitemap does not reflect live routes. Fetchers with short timeouts abandon long chains.",
            summary="Regenerate the sitemap from live routes and collapse redirect chains.",
            detail="Remove dead URLs from the sitemap and rewrite multi-hop redirects to point at the final destination in one hop.",
            effort="medium", verify="Re-crawl the sitemap sample; all entries return 200 within one hop.")
    return finding("D07", "pass", "high", f"{len(pages)-len(bad)}/{len(pages)} sampled URLs returned 200, no chain over 2 hops")


def d08(b):
    pages = [p for p in b.get("pages", []) if p.get("status") == 200]
    if not pages:
        return finding("D08", "unclear", "critical", "No successfully fetched pages to inspect.")
    hits = []
    for p in pages:
        xr = str(p.get("headers", {}).get("X-Robots-Tag", "")).lower()
        m = re.search(r'<meta[^>]+name=["\']robots["\'][^>]+content=["\']([^"\']+)', p.get("raw_html", ""), re.I)
        content = (m.group(1).lower() if m else "")
        blob = xr + " " + content
        flags = [d for d in ("noindex", "nosnippet", "max-snippet:0") if d in blob]
        if flags:
            hits.append((p.get("requested_url"), flags))
    if hits:
        return finding(
            "D08", "fail", "critical",
            f"{len(hits)}/{len(pages)} sampled pages carry {sorted({f for _, fs in hits for f in fs})}; e.g. " +
            ", ".join(u for u, _ in hits[:3]),
            mechanism="noindex removes the page from the index. nosnippet and max-snippet:0 are subtler: the page stays indexed but no text may be quoted from it, so an assistant can find the page and still cite nothing from it.",
            summary="Remove indexing directives from content routes.",
            detail="Strip noindex, nosnippet and max-snippet:0 from content pages. Check the X-Robots-Tag header as well as the meta tag — CDN-level headers are easy to set globally and easy to forget. Keep the directives on thank-you pages, internal search results and paginated duplicates.",
            effort="low", verify="curl -sI a content URL and confirm no X-Robots-Tag, and no robots meta in the HTML.")
    return finding("D08", "pass", "critical", f"0/{len(pages)} sampled pages carry noindex, nosnippet or max-snippet:0")


def main():
    ap = argparse.ArgumentParser(description="Evaluate crawl-access checks D01-D08 against a crawl bundle.")
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--out", default="access-findings.json")
    a = ap.parse_args()
    with open(a.bundle, encoding="utf-8") as f:
        b = json.load(f)
    prefixes = content_prefixes(b)
    out = [d01(b), d02(b, prefixes), d03(b), d04(b), d05(b), d06(b), d07(b), d08(b)]
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(json.dumps({r["check_id"]: r["result"] for r in out}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
