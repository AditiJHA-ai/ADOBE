---
name: entity-corroboration
description: >
  Checks whether facts on a site are attached to the right entity and believed
  by the wider web — brand-name ambiguity, sameAs links to external
  authorities, consistency of name/address/descriptor, corroboration of
  headline claims by independent sources, superseded on-site claims. Use as
  the fourth diagnostic stage, or standalone when assistants confuse the brand
  with a similarly named company or repeat stale facts.
license: MIT
allowed-tools: Bash, Read, WebSearch, WebFetch
---

# Entity and corroboration audit

Fourth stage of `brand-ai-readiness-audit`. The only skill that looks beyond
the site — a page can be perfectly crawlable, readable and marked up, and
still lose because nothing else on the web agrees with it.

## Input

`bundle.json`, plus web search access.

## Procedure

1. Extract the brand name (Organization schema, `<title>`, or `brand_name` arg).
2. **D22 ambiguity** — search the bare name; 3+ distinct entities with no
   disambiguating signal on the site is a failure.
3. **D23 sameAs** — collect from Organization schema; Wikidata/Wikipedia/
   LinkedIn/Crunchbase/registry links outweigh social profiles alone.
4. **D24 consistency** — compare name/address/phone/descriptor across
   homepage, about, contact, footer.
5. **D25 corroboration** — take 3 headline claims; search for an independent
   source per claim. Own-domain-only is fragile.
6. **D26 dates** — `n/a` for sites with no time-sensitive content.
7. **D27 superseded facts** — compare leadership/pricing/product claims
   against current external sources.
Steps 2, 5, 7 are judgement calls — record the searches performed as evidence.

## Checks

| ID | Check | Severity |
| --- | --- | --- |
| D22 | Brand name unambiguous or actively disambiguated | high |
| D23 | sameAs links to external authorities | high |
| D24 | Consistent name, address, phone and descriptor | medium |
| D25 | Core claims corroborated by 2+ independent sources | high |
| D26 | Visible published/updated dates on time-sensitive pages | medium |
| D27 | No stale facts contradicted by current external sources | high |

Method detail: `references/corroboration-method.md`.

## Output

JSON array of finding records. Evidence must name the searches run and sources
checked, not just the verdict.

## Guardrails

Read-only. Public pages only, no authenticated/paywalled sources. Never assert
a fact is wrong on one contradicting source — require two, or mark `unclear`.
Never report "doesn't rank for a generic category query" as a site defect.
