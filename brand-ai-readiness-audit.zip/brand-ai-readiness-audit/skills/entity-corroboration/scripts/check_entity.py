import argparse
import json
import re
import sys
from urllib.parse import urlparse

from bs4 import BeautifulSoup

AUTHORITY = ("wikidata.org", "wikipedia.org", "crunchbase.com", "linkedin.com/company",
             "opencorporates.com", "orcid.org", "ror.org", "sec.gov", "gov.uk", "bloomberg.com")
SOCIAL = ("facebook.com", "twitter.com", "x.com", "instagram.com", "tiktok.com",
          "pinterest.com", "youtube.com", "threads.net")
ORG_TYPES = {"Organization", "Corporation", "LocalBusiness", "NGO", "GovernmentOrganization",
             "EducationalOrganization", "MedicalOrganization", "OnlineBusiness", "Store"}
TIME_SENSITIVE = ("/news", "/blog", "/article", "/articles", "/posts", "/stories",
                  "/press", "/pricing", "/plans", "/product")
PHONE = re.compile(r"\+?\d[\d\s\-().]{7,}\d")


def finding(cid, title, result, severity, evidence, mechanism="", summary="", detail="",
            effort="medium", verify="", detail_result=None):
    return {"check_id": cid, "skill": "entity-corroboration", "category": "discoverability",
            "title": title, "result": result, "result_detail": detail_result, "severity": severity,
            "mechanism": mechanism, "evidence": evidence,
            "suggested_action": {"summary": summary, "detail": detail,
                                 "priority": severity, "effort": effort, "verify": verify}}


def soup_of(page):
    html = page.get("rendered_html") or page.get("raw_html") or ""
    return BeautifulSoup(html, "html.parser")


def visible_text(soup):
    s = BeautifulSoup(str(soup), "html.parser")
    for t in s(["script", "style", "noscript", "template", "svg"]):
        t.decompose()
    return re.sub(r"\s+", " ", s.get_text(" ")).strip()


def flatten(node, out):
    if isinstance(node, list):
        for n in node:
            flatten(n, out)
    elif isinstance(node, dict):
        if "@type" in node:
            out.append(node)
        for k, v in node.items():
            if k != "@type" and isinstance(v, (dict, list)):
                flatten(v, out)
    return out


def all_nodes(pages):
    out = []
    for p in pages:
        for t in soup_of(p).find_all("script", type=re.compile(r"ld\+json", re.I)):
            try:
                out = flatten(json.loads(t.string or t.get_text() or ""), out)
            except (json.JSONDecodeError, TypeError):
                continue
    return out


def org_nodes(nodes):
    out = []
    for n in nodes:
        t = n.get("@type")
        t = set(t) if isinstance(t, list) else {t}
        if t & ORG_TYPES:
            out.append(n)
    return out


def brand_name(bundle, pages, nodes):
    for n in org_nodes(nodes):
        if isinstance(n.get("name"), str) and n["name"].strip():
            return n["name"].strip()
    if pages:
        t = soup_of(pages[0]).find("title")
        if t:
            return re.split(r"[|\-–—]", t.get_text(strip=True))[0].strip()
    return bundle.get("site", "")


def norm_phone(s):
    d = re.sub(r"\D", "", s)
    return d[-10:] if len(d) >= 10 else d


def d23(nodes):
    orgs = org_nodes(nodes)
    if not nodes:
        return finding("D23", "No structured data to inspect for sameAs", "n/a", "high",
                       "No JSON-LD present; reported under D16.")
    links = []
    for n in orgs:
        sa = n.get("sameAs")
        links += sa if isinstance(sa, list) else [sa] if isinstance(sa, str) else []
    links = [l for l in links if isinstance(l, str) and l.strip()]
    auth = [l for l in links if any(a in l.lower() for a in AUTHORITY)]
    social = [l for l in links if any(s in l.lower() for s in SOCIAL)]
    ev = (f"{len(links)} sameAs link(s): {len(auth)} authority, {len(social)} social"
          + (f"; e.g. {links[:3]}" if links else ""))
    if auth:
        return finding("D23", "Entity is linked to external authorities", "pass", "high", ev)
    if links:
        return finding(
            "D23", "sameAs links point only to social profiles", "fail", "high", ev,
            mechanism="sameAs is the explicit statement that this entity is that entity. Social profiles are weak anchors because anyone can create one; an authority record is what lets a system resolve the brand against a known entity.",
            summary="Add authority links to sameAs alongside the social profiles.",
            detail="Claim the Wikidata item and the LinkedIn company page, then add both to Organization.sameAs. Add the relevant business registry entry where one exists. Low effort, disproportionately effective.",
            effort="low", verify="Organization.sameAs contains at least one wikidata.org or linkedin.com/company URL.",
            detail_result="partial")
    return finding(
        "D23", "No sameAs links to external identity records", "fail", "high",
        ev + f" across {len(orgs)} Organization node(s)",
        mechanism="Without sameAs, a system must infer identity from name matching alone — which is exactly what fails when several organisations share a name.",
        summary="Add Organization.sameAs linking to external identity records.",
        detail="Link Wikidata, Wikipedia, LinkedIn company page, Crunchbase, or the relevant official registry. Two or more, at least one an authority rather than a social profile.",
        effort="low", verify="Organization.sameAs is present and contains an authority URL.")


def d24(pages, nodes):
    phones, names, addrs = {}, set(), set()
    for p in pages:
        text = visible_text(soup_of(p))
        for m in PHONE.findall(text):
            n = norm_phone(m)
            if len(n) >= 7:
                phones.setdefault(n, []).append(urlparse(p.get("final_url", "")).path or "/")
    for n in org_nodes(nodes):
        if isinstance(n.get("name"), str):
            names.add(n["name"].strip().lower())
        a = n.get("address")
        if isinstance(a, dict):
            addrs.add(" ".join(str(v).strip().lower() for k, v in sorted(a.items())
                               if k != "@type" and isinstance(v, str)))
        elif isinstance(a, str):
            addrs.add(a.strip().lower())
    issues = []
    if len(names) > 1:
        issues.append(f"organisation name differs across schema nodes: {sorted(names)}")
    if len(addrs) > 1:
        issues.append(f"{len(addrs)} distinct addresses in schema")
    ev = (f"{len(phones)} distinct phone number(s) across {len(pages)} pages; "
          f"{len(names)} schema name(s); {len(addrs)} schema address(es)")
    if issues:
        return finding(
            "D24", "Organisation details are inconsistent across the site", "fail", "medium",
            ev + "; " + "; ".join(issues),
            mechanism="Systems cross-reference name, address and phone to confirm two mentions describe the same organisation. Inconsistency weakens every match and, for local entities, splits the record into duplicates.",
            summary="Render name, address and phone from one source across all templates.",
            detail="Pick the canonical values, render them from a single partial or config, and mirror them in LocalBusiness schema so markup and page cannot drift.",
            effort="low", verify="Name, address and phone are byte-identical wherever they appear.")
    if len(phones) > 2:
        return finding(
            "D24", "Several distinct phone numbers in use", "fail", "medium",
            ev + f"; numbers: {sorted(phones)[:4]}",
            mechanism="Multiple contact numbers may be legitimate departments or branches, or may be stale numbers left in old templates. Systems cannot tell the difference and may attach the wrong one to the entity.",
            summary="Confirm each number is current and label its purpose.",
            detail="Where the numbers are intentional, expose them as distinct contactPoint entries with contactType. Where they are legacy, remove them.",
            effort="low", verify="Every phone number on the site appears in a labelled contactPoint.",
            detail_result="partial")
    return finding("D24", "Organisation details are consistent", "pass", "medium", ev)


def d26(pages, nodes):
    ts = [p for p in pages if any(h in (urlparse(p.get("final_url", "")).path or "/").lower()
                                  for h in TIME_SENSITIVE)]
    if not ts:
        return finding("D26", "No time-sensitive pages to date", "n/a", "medium",
                       f"None of the {len(pages)} sampled pages is a news, blog, pricing or product page; "
                       "date checks do not apply to this site type.")
    dated_schema = sum(1 for n in nodes if n.get("dateModified") or n.get("datePublished"))
    visible = 0
    for p in ts:
        text = visible_text(soup_of(p))
        if re.search(r"\b(20[12]\d)[-/]\d{1,2}[-/]\d{1,2}\b", text) or \
           re.search(r"\b\d{1,2}\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+20[12]\d\b", text, re.I) or \
           re.search(r"\b(updated|published|last modified)\b", text, re.I):
            visible += 1
    ev = (f"{len(ts)} time-sensitive page(s) sampled; {dated_schema} schema node(s) carry a date; "
          f"{visible}/{len(ts)} show a visible date or update marker")
    if dated_schema and visible:
        return finding("D26", "Time-sensitive pages carry dates", "pass", "medium", ev)
    if dated_schema or visible:
        return finding(
            "D26", "Time-sensitive pages carry only one of schema or visible dates", "fail", "medium", ev,
            mechanism="A visible date without dateModified is invisible to extractors; dateModified without a visible date cannot be confirmed by a reader.",
            summary="Emit dateModified and display it.",
            detail="Show a real content edit date, not the build timestamp, and mirror it in structured data.",
            effort="low", verify="Time-sensitive pages show a visible date and expose dateModified.",
            detail_result="partial")
    return finding(
        "D26", "Time-sensitive pages carry no dates", "fail", "medium", ev,
        mechanism="Without a date a system cannot tell whether a fact is current, so it either declines to use it or quotes it with no freshness qualifier — which is how outdated pricing ends up presented as current.",
        summary="Add dateModified to time-sensitive page types and display it.",
        detail="Emit dateModified from the CMS on news, blog, pricing and product pages and render it visibly. Use the real edit date.",
        effort="low", verify="Sampled time-sensitive pages expose dateModified and show a visible date.")


def research_tasks(name, pages, nodes):
    """Emit the checks that need live search, as explicit instructions for the agent.

    D22, D25 and D27 cannot be decided from a crawl. Rather than guess, the script
    states exactly what to search and what threshold to apply, and leaves each check
    `unclear` until the agent fills it in.
    """
    claims = []
    for p in pages[:3]:
        for h in soup_of(p).find_all(["h1", "h2"]):
            t = h.get_text(" ", strip=True)
            if 20 < len(t) < 140 and re.search(r"\d|first|leading|largest|only|award", t, re.I):
                claims.append(t)
    return {
        "brand_name": name,
        "D22": {"search": [name, f'"{name}" company'],
                "decide": "Count distinct real-world entities in the first page of results. Fail if >=3 share the name and the site supplies no sameAs, alternateName or category-qualified description.",
                "severity": "high"},
        "D25": {"claims_to_verify": claims[:3] or ["No quantified headline claims found on sampled pages"],
                "decide": "For each claim, find sources not controlled by the brand. Syndicated press releases do not count. Fail if a claim appears only on the brand's own domain; partial at exactly one independent source.",
                "severity": "high"},
        "D27": {"search": [f"{name} CEO", f"{name} pricing", f"{name} products"],
                "decide": "Fail only if two or more independent current sources contradict the site. One contradicting source means unclear, not fail — the brand is usually the authority on itself.",
                "severity": "high"},
        "reminder": "Do not report failure to rank for a generic category query as a site defect. Category queries are commonly answered by comparison content, and that is not evidence of a broken site.",
    }


def main():
    ap = argparse.ArgumentParser(description="Evaluate entity checks D23, D24, D26 and emit research tasks for D22, D25, D27.")
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--out", default="entity-findings.json")
    ap.add_argument("--tasks", default="entity-research-tasks.json")
    a = ap.parse_args()
    with open(a.bundle, encoding="utf-8") as f:
        b = json.load(f)

    pages = [p for p in b.get("pages", []) if p.get("status") == 200 and (p.get("raw_html") or p.get("rendered_html"))]
    if not pages:
        out = [finding(c, "Not evaluated", "unclear", "high", "No pages were fetched successfully.")
               for c in ("D22", "D23", "D24", "D25", "D26", "D27")]
        tasks = {}
    else:
        nodes = all_nodes(pages)
        name = brand_name(b, pages, nodes)
        tasks = research_tasks(name, pages, nodes)
        pending = [
            finding("D22", "Brand-name ambiguity not yet assessed", "unclear", "high",
                    f"Requires live search for {name!r}. See entity-research-tasks.json."),
            finding("D25", "Claim corroboration not yet assessed", "unclear", "high",
                    f"Requires live search for {len(tasks['D25']['claims_to_verify'])} claim(s). See entity-research-tasks.json."),
            finding("D27", "Stale-fact check not yet assessed", "unclear", "high",
                    "Requires comparison against current external sources. See entity-research-tasks.json."),
        ]
        out = [d23(nodes), d24(pages, nodes), d26(pages, nodes)] + pending

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    with open(a.tasks, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False)
    print(json.dumps({r["check_id"]: r["result"] for r in out}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
