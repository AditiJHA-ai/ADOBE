# Entity and corroboration — method, thresholds, rationale

The only stage that looks beyond the site — these defects don't live on the
site, which is why every other check misses them.

## Three failure modes that look identical

| Observation | Mechanism | Site defect? |
| --- | --- | --- |
| Assistants describe a different company under this name | Entity ambiguity | Yes — disambiguation + sameAs |
| Assistants repeat an outdated fact | Stale corroboration | Yes — correct the off-site record |
| Assistants answer a category query with comparison sites instead of this brand | Category-association gap | **Often not** — the brand's own page can't be the neutral comparison a category query wants |

**Never report "doesn't rank for a generic category query" as a site defect.**
Report it as a category-association observation with an off-site recommendation.

## D22 — Brand name unambiguous or actively disambiguated
**Method:** search the bare name; count distinct real-world entities in first page.
**Fail:** 3+ distinct entities AND no disambiguating signal (no sameAs to an
authority, no category-qualified description, no alternateName/legalName).
**Fix:** `Organization.sameAs` to Wikidata/Wikipedia/LinkedIn/Crunchbase/registry;
add alternateName/legalName; make the description category-qualified ("Meridian
— dental clinics in Leeds", not "excellence in everything").

## D23 — sameAs links to external authorities
**Method:** collect `sameAs`; classify as **authority** (Wikidata, Wikipedia,
Crunchbase, LinkedIn company page, official registry, ORCID, ROR) vs **social**
(Facebook, X, Instagram, TikTok, Pinterest, YouTube).
**Fail:** none at all. **Partial:** social-only or <2 links. **Pass:** >=1 authority link.
4 social profiles with no Wikidata is much weaker than 1 Wikidata entry —
don't report both as "pass".
**Fix:** claim the Wikidata item + LinkedIn company page; link both.

## D24 — Consistent name, address, phone, descriptor
**Method:** compare across homepage/about/contact/footer. Normalise before
comparing (formatting differences aren't inconsistency; `St.` == `Street`).
**Fail:** materially different values in different places. **Partial:** >2
distinct phone numbers (may be legitimate branches — needs human judgement).
**Fix:** render name/address/phone from one source across templates.

## D25 — Core claims corroborated by independent sources
**Method:** 3 headline claims (flagship stat, founding/scale claim,
distinguishing capability); search an independent source per claim (press,
regulator filings, partner site, industry database — not syndicated press releases).
**Fail:** appears only on brand's own domain + syndication. **Partial:** 1 independent source.
**Fix (off-site):** get the claim into an industry directory, regulator
register, partner case study, or coverage citing the figure.

## D26 — Visible published/updated dates on time-sensitive pages
**Method:** news/blog/pricing/product pages: `dateModified`/`datePublished` in
schema AND a visible date in text. **N/A:** no time-sensitive content (common,
not a defect — scope to time-sensitive page types, not the homepage).
**Fail:** neither present. **Partial:** one only.
**Fix:** emit `dateModified` from the CMS and display a real edit date.

## D27 — No stale facts contradicted by current external sources
**Method:** check leadership/pricing/product lineup/headline stats against
current external sources. **Fail:** 2+ independent sources contradict.
**Unclear:** exactly one contradicts — record, don't assert.
Requiring two sources is deliberate: one blog post shouldn't overrule the
brand's own authority on itself.
**Fix:** correct the on-site page first, then pursue the external record.

## Reporting

Name the searches run and sources checked, not just the verdict: `Searched
"<name>"; results included <A>, <B>, <C> — three distinct entities; no sameAs`
is checkable, "brand name is ambiguous" is not. Off-site fixes must say so in
`suggested_action.detail` — a developer can't act on "improve corroboration".
