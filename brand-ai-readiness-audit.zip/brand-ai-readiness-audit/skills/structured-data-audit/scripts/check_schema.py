import argparse
import json
import re
import sys
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

ORG_TYPES = {"Organization", "Corporation", "LocalBusiness", "NGO", "GovernmentOrganization",
             "EducationalOrganization", "MedicalOrganization", "OnlineBusiness", "Store"}
REQUIRED = {
    "Organization": ["name", "url", "logo", "description"],
    "LocalBusiness": ["name", "url", "address", "telephone"],
    "Product": ["name", "offers"],
    "Offer": ["price", "priceCurrency", "availability"],
    "Article": ["headline", "datePublished", "author"],
    "NewsArticle": ["headline", "datePublished", "author"],
    "BlogPosting": ["headline", "datePublished", "author"],
    "FAQPage": ["mainEntity"],
}
COMPARABLE = ("name", "price", "telephone", "headline")
COMMERCE_HINTS = ("/product", "/products", "/shop", "/cart", "/checkout", "/store", "/collections")
PUBLISHER_HINTS = ("/news", "/blog", "/article", "/articles", "/posts", "/stories")
SAAS_HINTS = ("/pricing", "/plans", "/features", "/docs")


def finding(cid, title, result, severity, evidence, mechanism="", summary="", detail="",
            effort="medium", verify="", detail_result=None, rendered_ok=None):
    rec = {"check_id": cid, "skill": "structured-data-audit", "category": "discoverability",
           "title": title, "result": result, "result_detail": detail_result, "severity": severity,
           "mechanism": mechanism, "evidence": evidence,
           "suggested_action": {"summary": summary, "detail": detail,
                                "priority": severity, "effort": effort, "verify": verify}}
    if rendered_ok is not None:
        rec["passes_on_rendered_dom"] = rendered_ok
    return rec


def dom_for(page, prefer_rendered):
    html = page.get("rendered_html") if prefer_rendered and page.get("rendered_html") else page.get("raw_html")
    return BeautifulSoup(html or "", "html.parser")


def visible_text(soup):
    s = BeautifulSoup(str(soup), "html.parser")
    for t in s(["script", "style", "noscript", "template", "svg"]):
        t.decompose()
    return re.sub(r"\s+", " ", s.get_text(" ")).strip()


def flatten(node, out):
    """Collect every typed node, descending through @graph and nested entities.

    Reading only top-level @type reports a false absence on the many sites that wrap
    everything in a single @graph.
    """
    if isinstance(node, list):
        for n in node:
            flatten(n, out)
    elif isinstance(node, dict):
        if "@type" in node:
            out.append(node)
        for k, v in node.items():
            if k != "@type" and isinstance(v, (dict, list)):
                flatten(v, out)
    return out


def jsonld_of(soup):
    blocks, errors = [], []
    for t in soup.find_all("script", type=re.compile(r"ld\+json", re.I)):
        raw = t.string or t.get_text() or ""
        try:
            blocks.append(json.loads(raw))
        except (json.JSONDecodeError, TypeError) as e:
            errors.append(str(e)[:140])
    return flatten(blocks, []), errors


def types_of(nodes):
    out = set()
    for n in nodes:
        t = n.get("@type")
        out.update(t if isinstance(t, list) else [t] if t else [])
    return out


def other_markup(soup):
    kinds = []
    if soup.find(attrs={"itemscope": True}) or soup.find(attrs={"itemtype": True}):
        kinds.append("microdata")
    if soup.find(attrs={"typeof": True}) or soup.find(attrs={"vocab": True}):
        kinds.append("RDFa")
    return kinds


def site_type(bundle, pages, prefer_rendered):
    paths = " ".join((urlparse(p.get("final_url", "")).path or "/").lower() for p in pages)
    host = bundle.get("site", "")
    kinds = set()
    if any(h in paths for h in COMMERCE_HINTS):
        kinds.add("commerce")
    if any(h in paths for h in PUBLISHER_HINTS):
        kinds.add("publisher")
    if any(h in paths for h in SAAS_HINTS):
        kinds.add("saas_marketing")
    if re.search(r"\.(gov|edu)(\.[a-z]{2})?$", host or ""):
        kinds.add("institutional")
    all_nodes = []
    for p in pages:
        all_nodes += jsonld_of(dom_for(p, prefer_rendered))[0]
    t = types_of(all_nodes)
    if "LocalBusiness" in t or any("address" in n for n in all_nodes):
        kinds.add("local_business")
    return kinds or {"general"}


def collect(pages, prefer_rendered):
    per_page = []
    for p in pages:
        soup = dom_for(p, prefer_rendered)
        nodes, errors = jsonld_of(soup)
        per_page.append({"url": p.get("final_url"), "soup": soup, "nodes": nodes,
                         "errors": errors, "other": other_markup(soup)})
    return per_page


def d16(per_page):
    n = max(len(per_page), 1)
    with_jsonld = [p for p in per_page if p["nodes"] or p["errors"]]
    with_other = [p for p in per_page if p["other"] and not (p["nodes"] or p["errors"])]
    ev = (f"{len(with_jsonld)}/{n} sampled pages carry JSON-LD"
          + (f"; {len(with_other)} carry {sorted({k for p in with_other for k in p['other']})} instead" if with_other else ""))
    if len(with_jsonld) / n >= 0.6:
        return finding("D16", "Structured data is present on content pages", "pass", "high", ev)
    if with_other and (len(with_jsonld) + len(with_other)) / n >= 0.6:
        return finding(
            "D16", "Structured data uses legacy microdata rather than JSON-LD", "fail", "high", ev,
            mechanism="Microdata is read by fewer consumers than JSON-LD and is harder to keep correct because it is interleaved with presentation markup.",
            summary="Migrate the existing markup to JSON-LD.",
            detail="Emit the same entities as a JSON-LD block in the page head. The entity model is already worked out — this is a serialisation change, not a modelling one.",
            effort="medium", verify="Each page carries a script[type=application/ld+json] block describing its primary entity.",
            detail_result="partial")
    if with_jsonld:
        return finding(
            "D16", "Structured data is missing from most content pages", "fail", "high", ev,
            mechanism="Content pages are the ones that answer questions. Markup on the homepage alone identifies the company but leaves every specific fact unattributable.",
            summary="Add JSON-LD to content page templates, not just the homepage.",
            detail="Add the primary entity per page type: Product/Offer on product pages, Article on posts, FAQPage where questions are answered.",
            effort="medium", verify="Re-crawl the sample and confirm each page type carries its entity.",
            detail_result="partial")
    return finding(
        "D16", "No structured data of any kind", "fail", "high", ev,
        mechanism="Without structured data a system must infer what each number and name on the page means from surrounding prose. That inference is unreliable and unattributable, so the system declines to quote it and uses a source that can.",
        summary="Add JSON-LD to page templates, starting with the sitewide Organization.",
        detail="Add Organization and WebSite to the base template, then the primary entity for each page type. Template-level, not page by page.",
        effort="medium", verify="curl any page and find a script[type=application/ld+json] block in the source.")


def d17(per_page):
    bad = [(p["url"], p["errors"][0]) for p in per_page if p["errors"]]
    if not any(p["nodes"] or p["errors"] for p in per_page):
        return finding("D17", "No JSON-LD to validate", "n/a", "high", "No JSON-LD blocks present; reported under D16.")
    if not bad:
        total = sum(len(p["nodes"]) for p in per_page)
        return finding("D17", "JSON-LD parses cleanly", "pass", "high", f"All {total} JSON-LD blocks parse without error")
    return finding(
        "D17", "JSON-LD blocks fail to parse", "fail", "high",
        f"{len(bad)}/{len(per_page)} pages carry an unparseable block; e.g. {urlparse(bad[0][0]).path or '/'}: {bad[0][1]}",
        mechanism="A malformed block is discarded silently by every consumer. The markup is visible in the page source, so the site owner assumes it is working while nothing reads it.",
        summary="Validate structured data in CI.",
        detail="Most breakage comes from interpolating strings into JSON templates — unescaped quotes, trailing commas, unsubstituted template variables. Build the object in code and serialise it instead.",
        effort="low", verify="Every ld+json block on the sample parses with a standard JSON parser.")


def d18(per_page, kinds):
    nodes = [n for p in per_page for n in p["nodes"]]
    if not nodes:
        return finding("D18", "No structured data to type-check", "n/a", "high", "Reported under D16.")
    t = types_of(nodes)
    missing = []
    if not (t & ORG_TYPES):
        missing.append("Organization/LocalBusiness (sitewide entity)")
    if "commerce" in kinds and not ({"Product", "Offer"} & t):
        missing.append("Product/Offer on product pages")
    if "publisher" in kinds and not ({"Article", "NewsArticle", "BlogPosting"} & t):
        missing.append("Article on posts")
    if "local_business" in kinds and "LocalBusiness" not in t:
        missing.append("LocalBusiness with address")
    ev = f"Site type inferred as {sorted(kinds)}; schema types found: {sorted(t) or 'none'}"
    if not missing:
        return finding("D18", "Schema types match the site type", "pass", "high", ev)
    return finding(
        "D18", "Expected schema types are absent", "fail", "high", f"{ev}; missing {', '.join(missing)}",
        mechanism="The sitewide Organization block binds every other fact to a named entity. Without it a price, an address and a phone number are three unrelated strings rather than attributes of a company a system can name in an answer.",
        summary="Add the sitewide entity to the base template first, then per-page-type entities.",
        detail=f"Add {', '.join(missing)}. The sitewide entity is the highest-value single change here — everything else attaches to it via @id.",
        effort="medium", verify="Each page type exposes its expected @type in JSON-LD.")


def d19(per_page):
    nodes = [n for p in per_page for n in p["nodes"]]
    if not nodes:
        return finding("D19", "No structured data to inspect", "n/a", "high", "Reported under D16.")
    missing = []
    for n in nodes:
        raw = n.get("@type")
        for t in (raw if isinstance(raw, list) else [raw]):
            for prop in REQUIRED.get(t, []):
                if not n.get(prop):
                    missing.append(f"{t}.{prop}")
    if not missing:
        checked = sorted({t for n in nodes for t in ([n["@type"]] if isinstance(n.get("@type"), str) else n.get("@type") or []) if t in REQUIRED})
        return finding("D19", "Required schema properties are populated", "pass", "high",
                       f"All required properties present on {len(nodes)} node(s); types checked: {checked or 'none with requirements'}")
    uniq = sorted(set(missing))
    return finding(
        "D19", "Schema types are missing required properties", "fail", "high",
        f"{len(uniq)} missing required propert{'y' if len(uniq)==1 else 'ies'}: {', '.join(uniq[:6])}",
        mechanism="A Product with no offers.price is a name with nothing quotable attached — the markup exists, validates, and answers no question. priceCurrency matters as much: a bare number cannot be quoted safely to a user in another country.",
        summary="Populate required properties from the same source the visible page renders from.",
        detail=f"Fill {', '.join(uniq[:6])}. Generating markup and visible content from one source is what stops the two drifting apart later.",
        effort="medium", verify="Re-crawl and confirm no required property is empty.")


def d20(per_page):
    nodes_exist = any(p["nodes"] for p in per_page)
    if not nodes_exist:
        return finding("D20", "No structured data to cross-check", "n/a", "critical", "Reported under D16.")
    conflicts, unverified = [], 0
    for p in per_page:
        text = visible_text(p["soup"])
        digits = re.sub(r"\D", "", text)
        for n in p["nodes"]:
            for prop in COMPARABLE:
                v = n.get(prop)
                if isinstance(v, dict):
                    v = v.get("name") or v.get("price")
                if not isinstance(v, (str, int, float)):
                    continue
                v = str(v).strip()
                if len(v) < 3:
                    continue
                if prop == "telephone":
                    d = re.sub(r"\D", "", v)
                    if len(d) >= 7 and d[-10:] not in digits:
                        conflicts.append(f"{urlparse(p['url']).path or '/'}: schema telephone {v!r} not in page text")
                    continue
                if prop == "price":
                    bare = re.sub(r"[^\d.]", "", v).rstrip("0").rstrip(".")
                    if bare and bare.replace(".", "") not in digits:
                        conflicts.append(f"{urlparse(p['url']).path or '/'}: schema price {v!r} not in page text")
                    continue
                if v.lower() not in text.lower():
                    unverified += 1
    if conflicts:
        return finding(
            "D20", "Structured data contradicts the visible page", "fail", "critical",
            f"{len(conflicts)} value(s) in JSON-LD do not appear in the rendered page; e.g. {'; '.join(conflicts[:3])}",
            mechanism="Consumers trust explicit markup over parsed prose, so when the two disagree the markup wins. A stale Offer.price propagates into answers and shopping surfaces long after the visible page is corrected — and nothing on the site looks broken, so nobody notices.",
            summary="Generate markup and visible content from one source.",
            detail="Where they are generated separately, add a build-time assertion that the rendered value matches the value in JSON-LD, so a drift fails the build rather than shipping.",
            effort="medium", verify="Change the value in staging and confirm the JSON-LD changes with it.")
    return finding("D20", "Structured data agrees with the visible page", "pass", "critical",
                   f"Comparable values (name, price, telephone, headline) agree across {len(per_page)} sampled pages"
                   + (f"; {unverified} value(s) not present in visible text but not contradicted" if unverified else ""))


def norm(host):
    return (host or "").lower().split(":")[0].removeprefix("www.")


def d21(per_page, bundle):
    host = norm(bundle.get("site"))
    missing, offdomain, targets = [], [], []
    for p in per_page:
        link = p["soup"].select_one("link[rel~=canonical]")
        href = (link.get("href") or "").strip() if link else ""
        if not href:
            missing.append(urlparse(p["url"]).path or "/")
            continue
        absolute = urljoin(p["url"], href)
        targets.append(absolute.rstrip("/"))
        if norm(urlparse(absolute).netloc) != host:
            offdomain.append(f"{urlparse(p['url']).path or '/'} -> {absolute}")
    n = max(len(per_page), 1)
    base = (bundle.get("base_url") or "").rstrip("/")
    all_home = len(targets) > 2 and len(set(targets)) == 1 and targets[0] == base
    ev = (f"{len(missing)}/{n} pages missing a canonical; {len(offdomain)} off-domain"
          + ("; every canonical points at the homepage" if all_home else "")
          + f" (host normalised to {host!r})")
    if len(missing) / n > 0.4 or offdomain or all_home:
        return finding(
            "D21", "Canonical tags are missing or misconfigured", "fail", "medium", ev,
            mechanism="Without a canonical, content reachable at several URLs — trailing slash, tracking parameters, www and apex — is treated as several competing pages, splitting the authority the content earned. Every page pointing at the homepage is worse: it tells consumers to discard every interior page.",
            summary="Emit a self-referential absolute canonical from the page template.",
            detail="Set link[rel=canonical] to the page's own absolute URL, stripped of tracking parameters, on every content template.",
            effort="low", verify="Each sampled page's canonical resolves to itself after host normalisation.")
    return finding("D21", "Canonical tags are present and self-referential", "pass", "medium", ev)


def main():
    ap = argparse.ArgumentParser(description="Evaluate structured data checks D16-D21.")
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--out", default="schema-findings.json")
    a = ap.parse_args()
    with open(a.bundle, encoding="utf-8") as f:
        b = json.load(f)

    pages = [p for p in b.get("pages", []) if p.get("status") == 200 and (p.get("raw_html") or p.get("rendered_html"))]
    if not pages:
        out = [finding(c, "Not evaluated", "unclear", "high", "No pages were fetched successfully.")
               for c in ("D16", "D17", "D18", "D19", "D20", "D21")]
    else:
        rend = b.get("render", {})
        gap = bool(rend and not rend.get("render_error")) and any(
            p.get("rendered_text_len") and p.get("raw_text_len", 0) / p["rendered_text_len"] < 0.30 for p in pages)

        def run(prefer_rendered):
            per = collect(pages, prefer_rendered)
            kinds = site_type(b, pages, prefer_rendered)
            return [d16(per), d17(per), d18(per, kinds), d19(per), d20(per), d21(per, b)]

        out = run(False)
        if gap:
            rendered = {r["check_id"]: r for r in run(True)}
            for r in out:
                if r["result"] == "fail":
                    r["passes_on_rendered_dom"] = rendered[r["check_id"]]["result"] == "pass"
                    if r["passes_on_rendered_dom"]:
                        r["evidence"] += " (passes against the rendered DOM — consequence of the D09 render gap)"

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(json.dumps({r["check_id"]: r["result"] for r in out}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
