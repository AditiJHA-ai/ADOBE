---
name: structured-data-audit
description: >
  Checks whether a machine can lift a clean, attributable fact off the page —
  JSON-LD presence and parse validity, whether schema types match the site's
  purpose, required properties populated, structured data agreeing with visible
  text, canonical tags present and self-referential. Use as the third
  diagnostic stage of a brand AI-readiness audit, or standalone when assistants
  quote the wrong price, name or date.
license: MIT
allowed-tools: Bash, Read
---

# Structured data audit

Third stage of `brand-ai-readiness-audit`.

## Input

`bundle.json`. When `D09` failed, parse the rendered DOM instead of raw HTML
and set `passes_on_rendered_dom` accordingly.

## Procedure

1. Run `scripts/check_schema.py --bundle bundle.json --out schema-findings.json`.
2. Flatten `@graph` wrappers before reading types — schema nested in a graph is
   present; top-level-only parsing reports a false absence.
3. `D20` outranks `D16`: structured data that *contradicts* the visible page is
   worse than none — it supplies a confident wrong answer. Rank it critical.

## Checks

| ID | Check | Severity |
| --- | --- | --- |
| D16 | JSON-LD present on content pages | high |
| D17 | JSON-LD parses without errors | high |
| D18 | Schema types match the site type | high |
| D19 | Required properties populated per type | high |
| D20 | Structured data agrees with visible text | critical |
| D21 | Canonical present and self-referential | medium |

Expected types/properties by site type: `references/schema-expectations.md`.

## Output

JSON array of finding records. When `D16` finds no JSON-LD, mark `D17`, `D19`,
`D20`, `D23`, `D26` as `n/a` — one absence, reported once.

## Guardrails

Read-only, no network access. Normalise host and `www.` before judging a
canonical off-domain.
