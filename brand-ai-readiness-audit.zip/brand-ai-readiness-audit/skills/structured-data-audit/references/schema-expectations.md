# Structured data — expectations, thresholds, rationale

Answers: can a machine lift a clean, attributable fact off the page? Structured
data turns raw text into a fact attributed to a named entity, current now.

## Site-type inference

Infer before evaluating; record the inference in evidence. A site can be more
than one type — union the expectations.

| Site type | Signals |
| --- | --- |
| `commerce` | `/product`, `/shop`, `/cart`, `/checkout` routes; Product/Offer schema; currency near item names |
| `local_business` | Postal address, phone, map embed, `/locations` or `/contact` w/ address |
| `publisher` | `/news`, `/blog`, `/article` routes; bylines/dates; Article schema |
| `saas_marketing` | `/pricing`, `/features`, `/docs`, signup CTAs, no cart |
| `institutional` | `.gov`/`.edu`/`.org`, no commercial routes |

## D16 — JSON-LD present on content pages
**Detect:** `script[type=application/ld+json]`; also check microdata
(`itemscope`/`itemtype`) and RDFa before concluding absence.
**Fail:** none of any kind on >60% of pages. **Partial:** homepage only.
**Fix:** add JSON-LD to templates, starting with sitewide Organization + per-page-type entity.

## D17 — JSON-LD parses without errors
**Detect:** `json.loads` each block. **Fail:** any parse error. **N/A:** D16 empty.
Usual cause: string interpolation into JSON instead of serialising an object.
**Fix:** build the object, then serialise; validate in CI.

## D18 — Schema types match the site type
**Detect:** collect `@type`, flattening `@graph` first. Compare to expectations:

| Site type | Sitewide | Per page type |
| --- | --- | --- |
| any | Organization/LocalBusiness + WebSite | — |
| commerce | — | Product + Offer on product pages |
| local_business | LocalBusiness w/ address | openingHoursSpecification on contact |
| publisher | — | Article/NewsArticle on posts |
| saas_marketing | Organization, SoftwareApplication/Service | Offer on pricing |
| Q&A content | — | FAQPage where answered |

**Fix:** add the sitewide entity first (highest-value single change), then per-page-type.

## D19 — Required properties populated per type
| Type | Required |
| --- | --- |
| Organization | name, url, logo, description |
| LocalBusiness | name, url, address, telephone |
| Product | name, offers |
| Offer | price, priceCurrency, availability |
| Article/NewsArticle | headline, datePublished, author |
| FAQPage | mainEntity with >=1 Question+acceptedAnswer |
**Fail:** any required property missing/empty. **N/A:** D16 empty.
**Fix:** populate from the same data source the visible page renders from.

## D20 — Structured data agrees with visible text
**Detect:** compare schema `name`/`price`/`telephone`/`address`/dates against
visible text (normalise: strip currency symbols/separators, non-digit phone
chars, allow date-format differences).
**Fail:** any value contradicts visible page. **Unclear:** absent but not
contradicted (normal for `logo`/`sameAs`/`@id`).
**Most severe check in this stage — rank contradictions critical, above D16's absence.**
Wrong markup is worse than none: a confident wrong answer vs no answer.
**Fix:** generate markup and visible content from one source; add a build-time
assertion that rendered price matches `Offer.price`.
**Verify:** change the visible price in staging, confirm JSON-LD updates with it.

## D21 — Canonical present and self-referential
**Detect:** `link[rel=canonical]`; normalise host, strip leading `www.` both sides.
**Fail:** absent on >40% of pages, off-domain, or every page canonicalising to homepage.
**Fix:** self-referential absolute canonical per page from the template.
**Calibration:** comparing `example.com` against `www.example.com` literally
is the most common false-off-domain cause — normalise the host first.
