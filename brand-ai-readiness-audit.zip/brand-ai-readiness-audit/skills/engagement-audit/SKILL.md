---
name: engagement-audit
description: >
  Checks whether a visitor who arrives on the site stays — first-screen value
  statement, navigation/orientation cues (pricing, contact), interstitials/page
  weight/JS dependence, whether content pages offer a next step. Use as the
  engagement half of a brand AI-readiness audit, or standalone when traffic
  arrives but bounces or converts poorly.
license: MIT
allowed-tools: Bash, Read
---

# On-site engagement audit

Runs alongside the discoverability stages. Copy that never plainly states what
the org offers fails both the human skimming the first screen and the
extractor looking for a quotable claim — same root cause, often.

## Input

`bundle.json`. Use the rendered DOM for viewport-dependent checks (`E01`,
`E02`, `E04` — use the bundle's `above_fold` capture, not the whole document).

## Procedure

1. Run `scripts/check_engagement.py --bundle bundle.json --out engagement-findings.json`.
2. Apply site-type gating from `audit-orchestrator/references/suppression-rules.md`
   (e.g. a pricing check firing on a nonprofit/government site is a false positive).
3. `E01`, `E02`, `E12` need judgement — read the actual copy.

## Checks

| ID | Check | Severity |
| --- | --- | --- |
| E01 | Hero text states what the organisation offers | critical |
| E02 | First 200 words name the offering and the audience | high |
| E03 | Deep pages indicate where the visitor is | medium |
| E04 | Primary action identifiable in the first viewport | high |
| E05 | Pricing and contact reachable within one click | high |
| E06 | Landing page links to substantive internal pages | medium |
| E07 | Navigation consistent across page types | medium |
| E08 | No interstitial blocks content on load | high |
| E09 | Content readable without JavaScript | critical |
| E10 | Page weight and render-blocking resources reasonable | medium |
| E11 | Mobile viewport present and layout adapts | high |
| E12 | Common questions answered on-site | medium |
| E13 | Content pages offer a relevant next step | medium |

Thresholds/mechanisms: `references/checks.md`.

## Output

JSON array of finding records.

## Guardrails

Read-only, no network access beyond the shared bundle. Recommend copy/markup
changes only — never brand or visual identity.
