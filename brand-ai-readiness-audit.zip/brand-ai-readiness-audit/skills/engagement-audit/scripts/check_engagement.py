import argparse
import json
import re
import sys
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

UTILITY = re.compile(r"^(menu|search|close|accept|reject|cookies?|settings|skip|login|log in|"
                     r"sign in|sign up|toggle|open|back|next|previous|en|es|fr|de|language)\b", re.I)
VAGUE = {"click here", "read more", "more", "learn more", "here", "link", "details", ""}
PRICING = re.compile(r"pricing|plans|packages|tariff|fees|subscribe|buy|rates", re.I)
CONTACT = re.compile(r"contact|book|appointment|enquir|inquir|get in touch|support|help", re.I)
FAQ = re.compile(r"\bfaq|frequently asked|help cent|support cent|knowledge base|/docs|questions\b", re.I)
NONCOMMERCIAL = re.compile(r"\.(gov|edu)(\.[a-z]{2})?$|wikipedia|wikimedia", re.I)
AUDIENCE = re.compile(r"\bfor (small|large|new|busy|growing|independent|enterprise|freelance|student|"
                      r"teacher|developer|business|team|family|parent|patient|customer|beginner)", re.I)


def finding(cid, title, result, severity, evidence, mechanism="", summary="", detail="",
            effort="medium", verify="", detail_result=None, rendered_ok=None):
    rec = {"check_id": cid, "skill": "engagement-audit", "category": "engagement",
           "title": title, "result": result, "result_detail": detail_result, "severity": severity,
           "mechanism": mechanism, "evidence": evidence,
           "suggested_action": {"summary": summary, "detail": detail,
                                "priority": severity, "effort": effort, "verify": verify}}
    if rendered_ok is not None:
        rec["passes_on_rendered_dom"] = rendered_ok
    return rec


def soup_of(page):
    return BeautifulSoup(page.get("rendered_html") or page.get("raw_html") or "", "html.parser")


def visible_text(node):
    s = BeautifulSoup(str(node), "html.parser")
    for t in s(["script", "style", "noscript", "template", "svg"]):
        t.decompose()
    return re.sub(r"\s+", " ", s.get_text(" ")).strip()


def main_region(soup):
    for sel in ("main", "article", "[role=main]", "#content", ".content"):
        n = soup.select_one(sel)
        if n and len(visible_text(n)) > 200:
            return n
    s = BeautifulSoup(str(soup), "html.parser")
    for t in s(["script", "style", "noscript", "nav", "header", "footer", "svg"]):
        t.decompose()
    return s


def nav_links(soup):
    for sel in ("nav", "[role=navigation]", "header", ".nav", "#nav", ".navbar", ".menu"):
        n = soup.select_one(sel)
        if n:
            links = n.find_all("a", href=True)
            if links:
                return len(links)
    return 0


def is_noncommercial(bundle, pages):
    if NONCOMMERCIAL.search(bundle.get("site", "")):
        return True
    text = " ".join(visible_text(soup_of(p))[:3000] for p in pages[:3])
    return bool(re.search(r"\bnon[- ]?profit|charity|registered charity|open[- ]source foundation\b", text, re.I))


def e01(bundle, pages):
    af = next((p["above_fold"] for p in pages if p.get("above_fold")), None)
    if not af or not af.get("text"):
        return finding("E01", "Above-fold text not captured", "unclear", "critical",
                       "The rendered homepage above-fold capture is missing; cannot judge the hero copy.")
    text = af["text"][:600]
    return finding("E01", "Hero copy requires review", "unclear", "critical",
                   f"Above-fold text captured for review: {text!r}. Decide whether a stranger would learn "
                   "what the organisation sells or does. Fail if this is only a slogan, tagline or brand name.")


def e02(bundle, pages):
    if not pages:
        return finding("E02", "No page to read", "unclear", "high", "No pages fetched.")
    words = visible_text(main_region(soup_of(pages[0]))).split()[:200]
    opening = " ".join(words)
    has_audience = bool(AUDIENCE.search(opening))
    return finding("E02", "Opening copy requires review", "unclear", "high",
                   f"First {len(words)} words of main content: {opening[:500]!r}. "
                   f"Audience qualifier {'detected' if has_audience else 'not detected'} by pattern. "
                   "Decide whether both the offering and the audience are named.")


def e03(bundle, pages):
    deep = [p for p in pages if (urlparse(p.get("final_url", "")).path or "/").strip("/")]
    if not deep:
        return finding("E03", "No deep pages sampled", "n/a", "medium",
                       "Only the homepage was sampled; orientation cues cannot be assessed.")
    oriented = []
    for p in deep:
        soup = soup_of(p)
        html = str(soup)
        crumb = soup.select_one("[class*=breadcrumb i], [id*=breadcrumb i]") or "BreadcrumbList" in html
        active = soup.select_one("nav [class*=active i], nav [aria-current], header [aria-current]")
        heading = soup.find("h1")
        heading_ok = heading and len(heading.get_text(strip=True)) > 3
        if crumb or active or heading_ok:
            oriented.append(p)
    ev = f"{len(oriented)}/{len(deep)} deep pages give a location cue (breadcrumb, active nav state or page heading)"
    if len(oriented) >= len(deep) * 0.6:
        return finding("E03", "Deep pages orient the visitor", "pass", "medium", ev)
    return finding(
        "E03", "Deep pages give no location cue", "fail", "medium", ev,
        mechanism="Visitors land on deep pages far more often than homepages. With no cue the page is context-free and the only available action is back.",
        summary="Add breadcrumbs to pages more than one level deep.",
        detail="Render a visible breadcrumb and BreadcrumbList schema. This also gives systems a hierarchy they can use, so it pays twice.",
        effort="low", verify="Each deep page shows a breadcrumb and exposes BreadcrumbList.")


def e04(bundle, pages):
    af = next((p["above_fold"] for p in pages if p.get("above_fold")), None)
    if af is None:
        return finding("E04", "Above-fold actions not captured", "unclear", "high",
                       "The rendered homepage above-fold capture is missing.")
    actions = [a for a in af.get("actions", []) if a and not UTILITY.match(a.strip())]
    ev = f"{len(actions)} non-utility action(s) in the first viewport: {actions[:6]}"
    if 1 <= len(actions) <= 8:
        return finding("E04", "A primary action is available above the fold", "pass", "high", ev)
    if not actions:
        return finding(
            "E04", "No primary action above the fold", "fail", "high", ev,
            mechanism="A visitor who has decided the page is relevant needs an obvious next step. With none in the first viewport the page is a dead end at the moment of highest intent.",
            summary="Add one clear primary action to the hero.",
            detail="Place a single prominent action naming what happens next — 'See pricing', 'Book an appointment' — in the first viewport.",
            effort="low", verify="One non-utility action renders above the fold at 1280x900.")
    return finding(
        "E04", "Too many competing actions above the fold", "fail", "high", ev,
        mechanism="When many calls to action compete, none reads as primary, which performs much like having none at all.",
        summary="Choose one primary action and demote the rest.",
        detail="Give a single action visual precedence. Move secondary actions below the fold or restyle them as secondary.",
        effort="low", verify="At most eight non-utility actions render above the fold, with one visually dominant.")


def e05(bundle, pages):
    if not pages:
        return finding("E05", "No page to scan", "unclear", "high", "No pages fetched.")
    soup = soup_of(pages[0])
    base = pages[0].get("final_url", "")
    host = (bundle.get("site") or "").lower()
    hits = {"pricing": [], "contact": []}
    for a in soup.find_all("a", href=True):
        href = urljoin(base, a["href"])
        if urlparse(href).netloc.lower().removeprefix("www.") != host:
            continue
        blob = f"{a.get_text(' ', strip=True)} {href}"
        if PRICING.search(blob):
            hits["pricing"].append(href)
        if CONTACT.search(blob):
            hits["contact"].append(href)
    noncommercial = is_noncommercial(bundle, pages)
    required = ["contact"] if noncommercial else ["pricing", "contact"]
    missing = [k for k in required if not hits[k]]
    ev = (f"pricing links: {len(hits['pricing'])}, contact links: {len(hits['contact'])}"
          + ("; site classified non-commercial, pricing not required" if noncommercial else "")
          + (f"; e.g. {hits['contact'][0]}" if hits["contact"] else ""))
    if not missing:
        return finding("E05", "Pricing and contact are one click away", "pass", "high", ev)
    return finding(
        "E05", f"No one-click link to {', '.join(missing)}", "fail", "high", ev,
        mechanism="Pricing and contact are the two things visitors most often arrive already intending to find. Burying them converts a ready visitor into a bounce.",
        summary=f"Add {', '.join(missing)} to the primary navigation.",
        detail="Put both in the top-level nav with plain labels. 'Pricing' beats 'Solutions'.",
        effort="low", verify="Both links appear in the homepage navigation.")


def e06(bundle, pages):
    if not pages:
        return finding("E06", "No page to scan", "unclear", "medium", "No pages fetched.")
    soup = soup_of(pages[0])
    region = main_region(soup)
    base, host = pages[0].get("final_url", ""), (bundle.get("site") or "").lower()
    links, anchors = set(), []
    for a in region.find_all("a", href=True):
        href = urljoin(base, a["href"])
        if urlparse(href).netloc.lower().removeprefix("www.") == host:
            links.add(href.split("#")[0])
            anchors.append(a.get_text(" ", strip=True).lower())
    vague = sum(1 for t in anchors if t in VAGUE)
    ev = f"{len(links)} unique internal links in main content, {vague}/{len(anchors)} with vague or empty anchor text"
    if len(links) >= 8 and vague <= len(anchors) * 0.5:
        return finding("E06", "Landing page links to substantive internal pages", "pass", "medium", ev)
    return finding(
        "E06", "Landing page offers few or poorly labelled internal links", "fail", "medium", ev,
        mechanism="Internal links are simultaneously the visitor's path deeper into the site and the crawler's path to pages the sitemap may not cover. Descriptive anchors also tell a system what the target is about before it fetches it.",
        summary="Link to real destinations with anchor text naming the destination.",
        detail="Replace 'read more' with the destination's subject. Add links to the pages a first-time visitor would want next.",
        effort="low", verify="At least eight unique internal links with descriptive anchors on the landing page.")


def e07(bundle, pages):
    counts = [(urlparse(p.get("final_url", "")).path or "/", nav_links(soup_of(p))) for p in pages[:4]]
    vals = [c for _, c in counts]
    if not vals:
        return finding("E07", "Navigation not assessed", "unclear", "medium", "No pages fetched.")
    present = [v for v in vals if v > 0]
    ev = f"navigation link counts by page: {counts}"
    if not present:
        return finding(
            "E07", "No navigation region found on any page", "fail", "medium", ev,
            mechanism="Without navigation a visitor who lands on any page has no path to the rest of the site, and a crawler has no link graph to follow beyond the sitemap.",
            summary="Add a primary navigation region.",
            detail="Render a nav element with links to the main sections in a shared layout so every page inherits it.",
            effort="low", verify="Every sampled page exposes a nav region containing section links.")
    if len(present) < len(vals):
        return finding(
            "E07", "Navigation is missing on some page types", "fail", "medium", ev,
            mechanism="Visitors who land deep need the same orientation the homepage offers. Navigation that disappears strands them.",
            summary="Render navigation from one shared template.",
            detail="Move the nav into a shared layout so every page type inherits it.",
            effort="low", verify="Every sampled page type exposes the same navigation region.")
    if max(present) - min(present) > max(present) * 0.5:
        return finding(
            "E07", "Navigation varies substantially between page types", "fail", "medium", ev,
            mechanism="Inconsistent navigation forces the visitor to relearn the site on each page type.",
            summary="Use one navigation structure across page types.",
            detail="Where sections legitimately need extra links, add them as a secondary nav rather than replacing the primary one.",
            effort="medium", verify="Navigation link counts are comparable across page types.")
    return finding("E07", "Navigation is consistent", "pass", "medium", ev)


def e08(bundle):
    n = bundle.get("render", {}).get("overlay_count")
    if n is None:
        return finding("E08", "Overlay detection unavailable", "unclear", "high", "The render stage did not report overlays.")
    if not n:
        return finding("E08", "No blocking interstitial on load", "pass", "high",
                       "No fixed element covering over 40% of the viewport at z-index above 100")
    return finding(
        "E08", "An interstitial covers the content on load", "fail", "high",
        f"{n} fixed element(s) covering over 40% of the viewport at z-index above 100",
        mechanism="An overlay between arrival and content is a bounce prompt, and it fires before the visitor has seen anything worth staying for.",
        summary="Replace the full-viewport modal with a dismissible strip.",
        detail="Keep consent notices to a strip. Delay promotional interstitials until after meaningful interaction rather than firing on load.",
        effort="low", verify="Render the homepage and confirm no element obscures the first viewport.")


def e09(bundle):
    r = bundle.get("render", {})
    n = r.get("nojs_text_len")
    if n is None:
        return finding("E09", "No-JavaScript render unavailable", "unclear", "critical",
                       "The JavaScript-disabled render did not complete.")
    if n >= 400:
        return finding("E09", "Content is readable without JavaScript", "pass", "critical",
                       f"{n} characters of visible text with JavaScript disabled")
    return finding(
        "E09", "Page is blank without JavaScript", "fail", "critical",
        f"Only {n} characters of visible text with JavaScript disabled",
        mechanism="Beyond automated readers, this covers visitors on degraded connections where scripts time out. A page blank without JavaScript is blank for them.",
        summary="Server-render the main content region.",
        detail="Same fix as D09: render the primary content server-side so it exists before hydration.",
        effort="high", verify="Load with JavaScript disabled and confirm the main content is present.")


def e10(bundle, pages):
    r = bundle.get("render", {})
    mb = r.get("bytes", 0) / 1e6
    reqs = r.get("requests", 0)
    blocking = 0
    if pages:
        head = soup_of(pages[0]).find("head")
        if head:
            blocking = len([s for s in head.find_all("script", src=True)
                            if not s.has_attr("async") and not s.has_attr("defer")])
    ev = f"{mb:.1f} MB across {reqs} requests, {blocking} render-blocking script(s) in head"
    if mb <= 5 and blocking <= 4:
        return finding("E10", "Page weight is reasonable", "pass", "medium", ev)
    return finding(
        "E10", "Page is heavy or render-blocked", "fail", "medium", ev,
        mechanism="Every render-blocking resource delays first paint and abandonment rises sharply with it. Heavy pages also hit fetch timeouts in automated readers.",
        summary="Defer non-critical scripts and reduce transfer size.",
        detail="Add async or defer to scripts in head, inline critical CSS, compress images and lazy-load anything below the fold.",
        effort="medium", verify="Transfer size under 5 MB and at most four render-blocking scripts in head.")


def e11(bundle, pages):
    if not pages:
        return finding("E11", "Mobile layout not assessed", "unclear", "high", "No pages fetched.")
    vp = soup_of(pages[0]).find("meta", attrs={"name": re.compile("^viewport$", re.I)})
    overflow = bundle.get("render", {}).get("mobile_overflow")
    if not vp:
        return finding(
            "E11", "No mobile viewport meta tag", "fail", "high", "meta[name=viewport] absent from the homepage",
            mechanism="Most assistant-referred traffic arrives on mobile. Without a viewport declaration the browser renders a desktop layout scaled down, which is effectively unusable.",
            summary="Add the viewport meta tag.",
            detail='Add <meta name="viewport" content="width=device-width, initial-scale=1"> to the base template.',
            effort="low", verify="The homepage source contains a viewport meta tag.")
    ev = f"viewport meta present ({(vp.get('content') or '')[:60]!r})"
    if overflow:
        return finding(
            "E11", "Layout overflows horizontally on mobile", "fail", "high",
            ev + "; document scroll width exceeds 390px at mobile viewport",
            mechanism="A page requiring horizontal scrolling is effectively unusable on mobile regardless of content quality.",
            summary="Find and fix the overflowing element.",
            detail="Usually a fixed-width table, image or preformatted block. Set max-width:100% and allow tables to scroll within their own container.",
            effort="medium", verify="No horizontal scroll at a 390px viewport.")
    return finding("E11", "Mobile layout adapts", "pass", "high", ev + ", no horizontal overflow at 390px")


def e12(bundle, pages):
    if len(pages) <= 1:
        return finding("E12", "Single-page site", "n/a", "medium",
                       "Only one page sampled; FAQ coverage does not apply.")
    blob = " ".join((p.get("final_url", "") + " " + visible_text(soup_of(p))[:4000]) for p in pages)
    if FAQ.search(blob) or "FAQPage" in " ".join(str(soup_of(p)) for p in pages[:3]):
        return finding("E12", "Question-shaped content is present", "pass", "medium",
                       "FAQ, help or docs content found across the sampled pages")
    return finding(
        "E12", "No question-shaped content found", "fail", "medium",
        f"No FAQ, help centre or docs content found across {len(pages)} sampled pages",
        mechanism="Question-shaped content is directly quotable, which makes it both the thing the visitor was looking for and the passage an extractor can lift. FAQPage schema on top compounds the benefit.",
        summary="Publish the questions support actually receives, with answers.",
        detail="Write them as HTML text, not a PDF or a chat widget, and mark them up with FAQPage so the Q&A pairs are machine-readable.",
        effort="medium", verify="An FAQ page exists in HTML and exposes FAQPage schema.")


def e13(bundle, pages):
    deep = [p for p in pages[1:]]
    if not deep:
        return finding("E13", "No content pages sampled", "n/a", "medium", "Only the homepage was sampled.")
    host = (bundle.get("site") or "").lower()
    dead = []
    for p in deep:
        region = main_region(soup_of(p))
        base = p.get("final_url", "")
        links = {urljoin(base, a["href"]).split("#")[0] for a in region.find_all("a", href=True)
                 if urlparse(urljoin(base, a["href"])).netloc.lower().removeprefix("www.") == host}
        if len(links) < 2:
            dead.append(urlparse(base).path or "/")
    ev = f"{len(dead)}/{len(deep)} sampled content pages have fewer than two contextual internal links"
    if len(dead) <= len(deep) * 0.5:
        return finding("E13", "Content pages offer a next step", "pass", "medium", ev)
    return finding(
        "E13", "Content pages are dead ends", "fail", "medium", ev + f"; e.g. {dead[:3]}",
        mechanism="A page with no onward path ends the session there, whatever the visitor's remaining intent.",
        summary="Add contextual links to the pages a reader of this page would want next.",
        detail="Link from within the body copy, not just a related-posts block, so the link carries the context that makes it worth following.",
        effort="low", verify="Each content page carries at least two contextual internal links.")


def main():
    ap = argparse.ArgumentParser(description="Evaluate engagement checks E01-E13.")
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--out", default="engagement-findings.json")
    a = ap.parse_args()
    with open(a.bundle, encoding="utf-8") as f:
        b = json.load(f)

    pages = [p for p in b.get("pages", []) if p.get("status") == 200 and (p.get("raw_html") or p.get("rendered_html"))]
    if not pages:
        out = [finding(f"E{i:02d}", "Not evaluated", "unclear", "high", "No pages were fetched successfully.")
               for i in range(1, 14)]
    else:
        out = [e01(b, pages), e02(b, pages), e03(b, pages), e04(b, pages), e05(b, pages),
               e06(b, pages), e07(b, pages), e08(b), e09(b), e10(b, pages), e11(b, pages),
               e12(b, pages), e13(b, pages)]
        render_gap = any(p.get("rendered_text_len") and p.get("raw_text_len", 0) / p["rendered_text_len"] < 0.30
                         for p in pages)
        for r in out:
            if r["check_id"] == "E09" and r["result"] == "fail" and render_gap:
                r["passes_on_rendered_dom"] = True
                r["evidence"] += " (shares its root cause with the D09 render gap)"

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(json.dumps({r["check_id"]: r["result"] for r in out}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
