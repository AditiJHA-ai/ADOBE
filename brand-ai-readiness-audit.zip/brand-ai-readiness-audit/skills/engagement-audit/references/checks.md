# Engagement checks — detection, thresholds, rationale

Answers: does the visitor who arrives stay? Several checks are the human-facing
mirror of a discoverability check (noted where true) — copy that never states
the offering fails both the visitor and the extractor, for the same reason.

`E01`, `E02`, `E04` depend on the `above_fold` capture in the bundle (rendered,
first viewport), not the whole document — counting whole-document elements
produces nonsense (e.g. carousel arrows/cookie widgets counted as buttons).

## E01 — Hero text states what the organisation offers
**Detect:** read above-fold text; would a stranger learn what's sold/done?
**Fail:** only a slogan/tagline/brand name. **Partial:** implied, never stated.
Judgement call — script marks `unclear`, agent decides.
**Fix:** plain-language offering in the first heading.

## E02 — First 200 words name the offering and the audience
**Detect:** check both *what it is* and *who it's for* appear.
**Fail:** neither. **Partial:** one.
**Fix:** open with a sentence naming offering + audience, not company history.

## E03 — Deep pages indicate where the visitor is
**Detect:** breadcrumbs (schema or classed element), active nav state, or a
heading naming the section — accept any of the three.
**Fail:** none of the three present on a deep page.
**Fix:** add BreadcrumbList schema + visible breadcrumb past one level deep.

## E04 — Primary action identifiable in the first viewport
**Detect:** action elements in `above_fold` with visible text, excluding nav/
utility controls (menu, search, close, accept, cookie, language switcher).
**Fail:** zero actions, or >8 competing ones after exclusions.
**Fix:** one primary action per page with visual precedence; demote the rest.

## E05 — Pricing and contact reachable within one click
**Detect:** homepage links for pricing (`pricing`, `plans`, `packages`,
`tariff`, `fees`) and contact (`contact`, `book`, `appointment`, `enquire`,
`support`) routes. **N/A for pricing:** institutional/reference/nonprofit/gov
sites with no commercial offering. **Fail:** applicable category >2 clicks or absent.
**Fix:** put both in primary navigation.

## E06 — Landing page links to substantive internal pages
**Detect:** unique internal links with descriptive anchor text (excl. nav/footer);
count vague anchors (`click here`, `read more`, empty).
**Fail:** <8 unique links, or >half anchors vague.
**Fix:** link to real destinations with anchor text naming the target.

## E07 — Navigation consistent across page types
**Detect:** compare nav region (check `nav`, `[role=navigation]`, header link
cluster — all three) across homepage/mid-level/leaf page.
**Fail:** absent where present elsewhere, or link count varies >50% between types.
Sanity-bound the count — 441 nav links is meaningless, not a pass.
**Fix:** render navigation from one shared template.

## E08 — No interstitial blocks content on load
**Detect:** fixed-position elements covering >40% viewport, z-index >100.
**Fail:** present with no obvious dismissal. Consent strips are not failures —
only full-viewport overlays.
**Fix:** dismissible strip, not a full-viewport modal; delay promo interstitials.

## E09 — Content readable without JavaScript
**Detect:** render with JS disabled; measure main content region.
**Fail:** blank/loading shell (<400 chars visible text).
Human-facing mirror of D09 — when both fail, one root cause; orchestrator
folds E09 into D09.
**Fix:** server-render the main content region (same fix as D09).

## E10 — Page weight and render-blocking resources reasonable
**Detect:** transfer size, request count, render-blocking scripts in `head`
(no `async`/`defer`). **Fail:** >5MB, or >4 render-blocking scripts.
**Fix:** defer non-critical scripts, inline critical CSS, lazy-load images.

## E11 — Mobile viewport present and layout adapts
**Detect:** `meta[name=viewport]` presence; render at 390px, check horizontal overflow.
**Fail:** viewport meta absent, or scroll width exceeds viewport.
**Fix:** add viewport meta; find the overflowing element (usually a fixed-width table/image).

## E12 — Common questions answered on-site
**Detect:** FAQ/help/support/docs content covering applicable categories
(pricing, delivery, returns, support, eligibility, booking). **N/A:**
single-purpose landing pages. **Fail:** none addressed anywhere.
**Fix:** publish real support questions with answers, marked up `FAQPage`.

## E13 — Content pages offer a relevant next step
**Detect:** internal links inside main content region (excl. nav/footer) per sampled page.
**Fail:** >half of sampled pages have fewer than two.
**Fix:** add contextual links to what a reader of this page would want next.

## Calibration
Loosened after firing on healthy sites: E03 accepts 3 signals (not just
breadcrumbs), E04 reads the viewport not the document, E07 checks multiple nav
selectors, E10 sits at 5MB not 3MB. A check firing on a site you believe is
healthy is evidence against the threshold, not the site.
