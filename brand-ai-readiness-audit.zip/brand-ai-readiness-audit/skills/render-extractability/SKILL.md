---
name: render-extractability
description: >
  Determines whether a machine can read a page a human can see — raw HTML vs
  rendered DOM to detect client-side render gaps, heading structure, title/meta
  description quality, body text volume, and whether key facts (pricing, hours,
  specs, contact) are locked inside images/PDFs rather than text. Use as the
  second diagnostic stage of a brand AI-readiness audit, or standalone when a
  site is indexed but assistants misquote or thinly summarise it.
license: MIT
allowed-tools: Bash, Read
---

# Render and extractability audit

Second stage of `brand-ai-readiness-audit`, after `crawl-access-audit`.

## Input

`bundle.json` from `audit-orchestrator/scripts/fetch_bundle.py`.

## Procedure

1. Run `scripts/check_render.py --bundle bundle.json --out render-findings.json`.
2. `D09` governs the rest: when it fails, re-evaluate every raw-HTML-derived
   check against the rendered DOM and flag `passes_on_rendered_dom` so the
   orchestrator folds it into `D09` as a consequence rather than a separate finding.
3. `D12`/`D13` need judgement: identify the site's key fact categories from its
   type, confirm each appears in body text — not only in an `<img>`, background
   image, canvas, or linked PDF.

## Checks

| ID | Check | Severity |
| --- | --- | --- |
| D09 | Primary content present in raw HTML, not JS-only | critical |
| D10 | Exactly one descriptive h1 per page | high |
| D11 | Title and meta description present, unique, descriptive | high |
| D12 | Key facts in text, not locked in images | critical |
| D13 | Key facts not available only inside PDFs | high |
| D14 | Body text volume adequate on content pages | medium |
| D15 | Headings form a usable hierarchy | medium |

Detection methods/thresholds: `references/checks.md`.

## Output

JSON array of finding records (schema: `audit-orchestrator/references/report-schema.md`).
Raw-HTML-derived checks must carry `passes_on_rendered_dom` when D09 failed.

## Guardrails

Read-only, no network access. Never recommend removing images — recommend
mirroring their factual content as text.
