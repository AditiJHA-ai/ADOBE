# Render and extractability checks — detection, thresholds, rationale

Answers: can a machine read what a human can see? Checks ordered so the one
governing all others comes first.

## D09 — Primary content present in raw HTML, not JS-only
**Detect:** visible text from raw HTTP response vs rendered DOM (strip
`script`/`style`/`noscript`/`template`/`svg`). Median `raw_len/rendered_len`
across the sample (median, not mean, so one outlier page doesn't skew it).
**Fail:** <0.30. **Partial:** 0.30-0.70. **Pass:** >0.70.
**Governs the stage:** when it fails, `D10`, `D11`, `D15`, `D16`, `D18`, `D19`,
`D21`, `D23` must be re-checked against the rendered DOM. Passes there ->
`passes_on_rendered_dom: true`, folded into D09 as a consequence. Fails there
too -> genuine separate finding. Skipping this turns one problem into eight
false positives.
**Fix:** server-render or pre-render the main content region; at minimum
inline core copy + JSON-LD into the server response before hydration.
**Verify:** curl the URL, confirm heading/body copy in the response.

## D10 — Exactly one descriptive h1 per page
**Detect:** count h1s; flag when zero, empty, alt-less image, or generic
(`Home`, `Welcome`, bare brand name). Multiple h1s are fine unless none
describes the page. **Fail:** >20% of sampled pages flagged.
**Fix:** one h1 naming the page subject in plain words.

## D11 — Title and meta description present, unique, descriptive
**Detect:** collect `<title>`/`meta[description]`; count missing/duplicated.
**Fail:** any page missing title, or >40% duplicated titles, or >40% missing
description. **Partial:** some descriptions missing, titles fine.
**Fix:** generate titles from content, not a sitewide template.

## D12 — Key facts in text, not locked in images
**Detect:** identify key fact categories from site type (pricing, hours,
contact, specs, address); check each appears in visible text; look for
countervailing image signals (filename/alt containing `price`, `menu`,
`hours`, `tariff`, `specs`, `pricelist`).
**Fail:** category absent from text while a carrying image is present.
**Unclear:** absent from text, no candidate image — report unclear, not fail.
**Fix:** render as HTML text; keep the image but mirror content as text/schema
(`openingHoursSpecification` for hours, `Offer.price` for prices).

## D13 — Key facts not available only inside PDFs
**Detect:** PDF links from nav/content; flag when a key fact category is
PDF-only with no HTML equivalent. **Fix:** publish an HTML version; keep the
PDF as a printable artifact, not the canonical source.

## D14 — Body text volume adequate on content pages
**Detect:** median visible word count of main content region (not nav/footer).
**Fail:** <150 words. **Partial:** 150-300. **Pass:** >300.
**Fix:** expand thin pages or consolidate several into one substantive page.

## D15 — Headings form a usable hierarchy
**Detect:** pages >400 words: h2s exist, no level-skipping (h1 -> h3) *throughout*.
**Fail:** long pages with zero h2s, or systematic skipping (not one-off).
**Fix:** add descriptive h2 sections, phrased as reader questions.

## Calibration
- Every threshold is a median/share, never a single-page verdict.
- D12/D13 return `unclear` freely — they exist to catch facts trapped in a
  JPG on a small-business site, not to fire on healthy sites.
- If a check fires on a site you believe is healthy, suspect the threshold
  before the site.
