import argparse
import json
import re
import statistics
import sys
from urllib.parse import urlparse

from bs4 import BeautifulSoup

GENERIC_H1 = {"home", "homepage", "welcome", "index", "untitled"}
FACT_IMAGE_HINTS = ("price", "pricing", "tariff", "rate", "fee", "menu", "hour", "timing",
                    "schedule", "spec", "pricelist", "chart", "table", "contact")
PDF_FACT_HINTS = ("price", "pricing", "tariff", "rate", "fee", "menu", "spec", "catalog",
                  "brochure", "policy", "terms", "profile", "about")
CURRENCY = re.compile(r"(?:[$£€₹¥]|\b(?:USD|EUR|GBP|INR|NOK|AUD|CAD)\b)\s?\d")
HOURS = re.compile(r"\b(?:mon|tue|wed|thu|fri|sat|sun)[a-z]*\b.{0,20}\d{1,2}\s*[:.]?\d{0,2}\s*(?:am|pm|-|–)", re.I)
PHONE = re.compile(r"\+?\d[\d\s\-()]{8,}\d")


def finding(cid, title, result, severity, evidence, mechanism="", summary="", detail="",
            effort="medium", verify="", detail_result=None, rendered_ok=None):
    rec = {"check_id": cid, "skill": "render-extractability", "category": "discoverability",
           "title": title, "result": result, "result_detail": detail_result, "severity": severity,
           "mechanism": mechanism, "evidence": evidence,
           "suggested_action": {"summary": summary, "detail": detail,
                                "priority": severity, "effort": effort, "verify": verify}}
    if rendered_ok is not None:
        rec["passes_on_rendered_dom"] = rendered_ok
    return rec


def soup_of(html):
    return BeautifulSoup(html or "", "html.parser")


def strip_chrome(soup):
    s = BeautifulSoup(str(soup), "html.parser")
    for t in s(["script", "style", "noscript", "template", "svg", "nav", "header", "footer"]):
        t.decompose()
    return s


def visible_text(soup):
    s = BeautifulSoup(str(soup), "html.parser")
    for t in s(["script", "style", "noscript", "template", "svg"]):
        t.decompose()
    return re.sub(r"\s+", " ", s.get_text(" ")).strip()


def main_region(soup):
    for sel in ("main", "article", "[role=main]", "#content", ".content"):
        node = soup.select_one(sel)
        if node and len(visible_text(node)) > 200:
            return node
    return strip_chrome(soup)


def ok_pages(bundle):
    return [p for p in bundle.get("pages", []) if p.get("status") == 200 and p.get("raw_html")]


def dom_for(page, prefer_rendered):
    html = page.get("rendered_html") if prefer_rendered and page.get("rendered_html") else page.get("raw_html")
    return soup_of(html)


def d09(bundle, pages):
    ratios, detail = [], []
    for p in pages:
        rend = p.get("rendered_text_len")
        if not rend:
            continue
        raw = p.get("raw_text_len", 0)
        ratios.append(raw / rend)
        detail.append(f"{urlparse(p['final_url']).path or '/'} {raw}/{rend}")
    if not ratios:
        return finding("D09", "Render gap could not be measured", "unclear", "critical",
                       "No page produced a rendered DOM; the browser stage did not complete.")
    med = statistics.median(ratios)
    ev = (f"Median raw/rendered visible-text ratio {med:.2f} across {len(ratios)} pages; "
          f"e.g. {'; '.join(detail[:3])}")
    if med > 0.70:
        return finding("D09", "Content is present in raw HTML", "pass", "critical", ev)
    return finding(
        "D09", "Primary content is only present after JavaScript executes",
        "fail", "critical", ev,
        mechanism="Assistants that fetch a URL without running a browser see the pre-hydration shell, so none of the page's substance is available to quote. The site can rank in conventional search, which does render JavaScript, and still be uncitable.",
        summary="Server-render or pre-render the main content region.",
        detail="Enable SSR for the content routes, or pre-render to static HTML at build time. At minimum, inline the core factual copy and the JSON-LD block into the server response so both exist before hydration.",
        effort="high",
        verify="curl the URL with no JavaScript and confirm the primary heading and body copy appear in the response body.",
        detail_result="partial" if med >= 0.30 else None)


def d10(bundle, pages, prefer_rendered):
    flagged, examples = [], []
    for p in pages:
        soup = dom_for(p, prefer_rendered)
        h1s = soup.find_all("h1")
        texts = [h.get_text(strip=True) for h in h1s]
        descriptive = [t for t in texts if t and t.lower() not in GENERIC_H1 and len(t) > 3]
        if not descriptive:
            flagged.append(p["final_url"])
            if len(examples) < 3:
                examples.append(f"{urlparse(p['final_url']).path or '/'} -> {texts or 'no h1'}")
    share = len(flagged) / max(len(pages), 1)
    ev = f"{len(flagged)}/{len(pages)} sampled pages lack a descriptive h1" + (f"; e.g. {'; '.join(examples)}" if examples else "")
    if share <= 0.20:
        first = next((h.get_text(strip=True) for p in pages for h in dom_for(p, prefer_rendered).find_all("h1")
                      if h.get_text(strip=True)), "")
        return finding("D10", "Pages carry a descriptive h1", "pass", "high",
                       f"{len(pages)-len(flagged)}/{len(pages)} sampled pages have a descriptive h1"
                       + (f", e.g. {first[:70]!r}" if first else ""))
    return finding(
        "D10", "Pages lack a descriptive h1", "fail", "high", ev,
        mechanism="The h1 is the strongest single signal of what a page is about, and extractors read it before the body to decide whether the page answers the query. With none, the extractor falls back to the first body text, which on many pages is a cookie notice.",
        summary="Give every page one h1 naming the page subject in plain words.",
        detail="Replace missing or generic h1 text with a phrase a stranger would recognise as the page subject. 'Family dental care in South Delhi' beats 'Welcome'.",
        effort="low", verify="Fetch each template and confirm exactly one non-generic h1 renders in the HTML source.")


def d11(bundle, pages, prefer_rendered):
    titles, descs, no_title, no_desc = [], [], [], []
    for p in pages:
        soup = dom_for(p, prefer_rendered)
        t = soup.find("title")
        t = t.get_text(strip=True) if t else ""
        d = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
        d = (d.get("content") or "").strip() if d else ""
        titles.append(t)
        descs.append(d)
        if not t:
            no_title.append(p["final_url"])
        if not d:
            no_desc.append(p["final_url"])
    n = max(len(pages), 1)
    dup = len(titles) - len(set(t for t in titles if t))
    ev = (f"{len(no_title)}/{n} pages missing <title>, {len(no_desc)}/{n} missing meta description, "
          f"{dup} duplicate titles")
    if no_title or dup > n * 0.4 or len(no_desc) > n * 0.4:
        return finding(
            "D11", "Titles or meta descriptions are missing or duplicated", "fail", "high", ev,
            mechanism="These two fields are what a retrieval system quotes when deciding whether a page is worth fetching in full. Duplicated titles also make pages indistinguishable to a deduplicating index, so only one survives.",
            summary="Generate titles and descriptions from page content, not a sitewide template.",
            detail="Give each page a unique title naming its specific subject, and a description stating the page's specific answer rather than brand boilerplate.",
            effort="low", verify="Crawl the sample again and confirm every page has a unique title and a non-empty description.",
            detail_result="partial" if not no_title and dup <= n * 0.4 else None)
    if no_desc:
        return finding("D11", "Some meta descriptions are missing", "fail", "high", ev,
                       mechanism="Extractors fall back to arbitrary body text when no description is supplied.",
                       summary="Add meta descriptions to the remaining pages.",
                       detail="Write a one-sentence description per page stating what it answers.",
                       effort="low", verify="Every sampled page returns a non-empty meta description.",
                       detail_result="partial")
    return finding("D11", "Titles and descriptions are present and unique", "pass", "high", ev)


def d12(bundle, pages, prefer_rendered):
    text = " ".join(visible_text(dom_for(p, prefer_rendered)) for p in pages)
    present = {"pricing": bool(CURRENCY.search(text)), "hours": bool(HOURS.search(text)),
               "contact": bool(PHONE.search(text))}
    candidates = []
    for p in pages:
        for img in dom_for(p, prefer_rendered).find_all("img"):
            blob = f"{img.get('src','')} {img.get('alt','')}".lower()
            if any(h in blob for h in FACT_IMAGE_HINTS):
                candidates.append(f"{urlparse(p['final_url']).path or '/'}: {img.get('src','')[:70]}")
    missing = [k for k, v in present.items() if not v]
    if missing and candidates:
        return finding(
            "D12", "Key facts appear only inside images", "fail", "critical",
            f"No {', '.join(missing)} value found in body text across {len(pages)} pages, "
            f"while {len(candidates)} image(s) plausibly carry it; e.g. {'; '.join(candidates[:3])}",
            mechanism="Text inside an image is not text. The fact exists, a human reads it instantly, and every automated reader returns nothing — which is the most common reason a site is found but cannot answer the question that brought the visitor.",
            summary="Render the value as HTML text alongside the image.",
            detail="Keep the image if it matters visually and mirror its content as text. For hours add openingHoursSpecification; for prices add Offer.price in JSON-LD.",
            effort="medium", verify="Search the rendered page text for the value and confirm it is found.")
    if missing:
        return finding("D12", "Key facts could not be located in text", "unclear", "critical",
                       f"No {', '.join(missing)} value found in body text and no candidate image identified. "
                       f"Searched {len(pages)} pages for currency patterns, day/time patterns and phone patterns. "
                       f"Confirm manually whether the site publishes these facts at all.")
    return finding("D12", "Key facts are stated as text", "pass", "critical",
                   f"Pricing, hours and contact patterns all found in body text across {len(pages)} sampled pages")


def d13(bundle, pages, prefer_rendered):
    pdfs, host = [], bundle.get("site", "")
    for p in pages:
        for a in dom_for(p, prefer_rendered).find_all("a", href=True):
            href = a["href"]
            if href.lower().split("?")[0].endswith(".pdf"):
                blob = f"{href} {a.get_text(' ', strip=True)}".lower()
                if any(h in blob for h in PDF_FACT_HINTS):
                    pdfs.append(f"{a.get_text(' ', strip=True)[:40]!r} -> {href[:70]}")
    text = " ".join(visible_text(dom_for(p, prefer_rendered)) for p in pages)
    has_price_text = bool(CURRENCY.search(text))
    if pdfs and not has_price_text:
        return finding(
            "D13", "Key facts are published only as PDFs", "fail", "high",
            f"{len(pdfs)} PDF link(s) covering fact categories with no HTML equivalent found; e.g. {'; '.join(pdfs[:3])}",
            mechanism="PDFs are fetched, parsed and quoted less reliably than HTML, and many retrieval pipelines skip them entirely. A price list that exists only as a PDF is, for practical purposes, unpublished.",
            summary="Publish an HTML version of the content.",
            detail="Mirror the PDF's substance as an HTML page and keep the PDF as the printable artifact, not the canonical source.",
            effort="medium", verify="The fact is present in the HTML of a page that returns text/html.")
    if pdfs:
        return finding("D13", "Fact-bearing PDFs exist alongside HTML", "pass", "high",
                       f"{len(pdfs)} fact-bearing PDF link(s) found, but equivalent values also appear in body text")
    return finding("D13", "No PDF-only facts detected", "pass", "high",
                   f"No fact-bearing PDF links found across {len(pages)} sampled pages")


def d14(bundle, pages, prefer_rendered):
    counts = [len(visible_text(main_region(dom_for(p, prefer_rendered))).split()) for p in pages]
    if not counts:
        return finding("D14", "Body text volume could not be measured", "unclear", "medium", "No pages to measure.")
    med = statistics.median(counts)
    ev = f"Median main-content word count {med} across {len(counts)} sampled pages (range {min(counts)}-{max(counts)})"
    if med > 300:
        return finding("D14", "Content pages carry adequate body text", "pass", "medium", ev)
    return finding(
        "D14", "Content pages are thin", "fail", "medium", ev,
        mechanism="Extractors need enough surrounding context to confirm that a fact on the page is the fact being asked about. A page may state the answer and still lose to a competitor that states it with context.",
        summary="Expand thin pages or consolidate them.",
        detail="Add the context a reader would actually want — what the thing is, who it is for, what it costs, what happens next — or merge several thin pages into one substantive page.",
        effort="medium", verify="Median main-content word count on the sample exceeds 300.",
        detail_result="partial" if med >= 150 else None)


def d15(bundle, pages, prefer_rendered):
    long_no_h2, skipping = [], []
    for p in pages:
        soup = dom_for(p, prefer_rendered)
        region = main_region(soup)
        words = len(visible_text(region).split())
        levels = [int(h.name[1]) for h in region.find_all(re.compile("^h[1-6]$"))]
        if words > 400 and 2 not in levels:
            long_no_h2.append(urlparse(p["final_url"]).path or "/")
        skips = sum(1 for a, b in zip(levels, levels[1:]) if b - a > 1)
        if levels and skips > max(len(levels) * 0.5, 2):
            skipping.append(urlparse(p["final_url"]).path or "/")
    if long_no_h2 or skipping:
        return finding(
            "D15", "Long pages lack a usable heading hierarchy", "fail", "medium",
            f"{len(long_no_h2)} page(s) over 400 words carry no h2; {len(skipping)} page(s) skip heading levels throughout; "
            f"e.g. {', '.join((long_no_h2 + skipping)[:3])}",
            mechanism="Headings are how an extractor segments a long page and decides which passage answers a question. A long page with no subheadings is one undifferentiated block: the system must return all of it or none, and usually returns none.",
            summary="Add descriptive h2 sections to long pages.",
            detail="Break long pages into h2 sections. Phrasing the headings as the questions readers actually ask makes each passage directly quotable.",
            effort="low", verify="Every page over 400 words contains at least two h2 elements.")
    return finding("D15", "Heading hierarchy is usable", "pass", "medium",
                   f"Long pages carry h2 subheadings across {len(pages)} sampled pages")


def main():
    ap = argparse.ArgumentParser(description="Evaluate render and extractability checks D09-D15.")
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--out", default="render-findings.json")
    a = ap.parse_args()
    with open(a.bundle, encoding="utf-8") as f:
        b = json.load(f)

    pages = ok_pages(b)
    if not pages:
        out = [finding(c, "Not evaluated", "unclear", "high", "No pages were fetched successfully.")
               for c in ("D09", "D10", "D11", "D12", "D13", "D14", "D15")]
    else:
        gap = d09(b, pages)
        render_failed = gap["result"] == "fail"
        out = [gap]
        for fn, cid in ((d10, "D10"), (d11, "D11"), (d12, "D12"),
                        (d13, "D13"), (d14, "D14"), (d15, "D15")):
            raw_result = fn(b, pages, False)
            if render_failed and raw_result["result"] == "fail":
                rendered_result = fn(b, pages, True)
                raw_result["passes_on_rendered_dom"] = rendered_result["result"] == "pass"
                if raw_result["passes_on_rendered_dom"]:
                    raw_result["evidence"] += " (passes against the rendered DOM — consequence of the D09 render gap)"
            out.append(raw_result)

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(json.dumps({r["check_id"]: r["result"] for r in out}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
