# brand-ai-readiness-audit

An Agent Skill Marketplace that audits any website for the defects that stop AI
assistants finding, trusting and citing it, and for the on-site defects that lose
the visitor once they arrive. It emits one structured report of findings plus
prioritized suggested actions.

**Recommend-only.** No skill in this marketplace modifies a live site, submits a
form, or makes an authenticated request. Everything runs read-only.

## Quick start

```bash
pip install requests beautifulsoup4 lxml playwright
playwright install chromium

python skills/audit-orchestrator/scripts/fetch_bundle.py example.com --out bundle.json --sample 10
python skills/crawl-access-audit/scripts/check_access.py      --bundle bundle.json --out access.json
python skills/render-extractability/scripts/check_render.py   --bundle bundle.json --out render.json
python skills/structured-data-audit/scripts/check_schema.py   --bundle bundle.json --out schema.json
python skills/entity-corroboration/scripts/check_entity.py    --bundle bundle.json --out entity.json --tasks tasks.json
python skills/engagement-audit/scripts/check_engagement.py    --bundle bundle.json --out engagement.json

python skills/audit-orchestrator/scripts/assemble_report.py \
  --findings access.json render.json schema.json entity.json engagement.json \
  --bundle bundle.json --proactive proactive.json --out report.json
```

Invoked as an agent skill, `audit-orchestrator` performs this sequence itself.

## Design

The defects form a chain. A crawler must be **let in** before it can **read** the
page, must read it before it can **extract a clean fact**, and must extract a fact
before the wider web can **corroborate** it. Engagement runs in parallel: it only
matters for visitors who already arrived.

The decomposition follows that chain, so each skill owns one mechanism rather than
one arbitrary slice of a checklist.

| Skill | Question it answers | Checks |
| --- | --- | --- |
| `audit-orchestrator` *(entrypoint)* | — crawls once, delegates, reconciles, emits the report | — |
| `crawl-access-audit` | Is the crawler let in? | D01–D08 |
| `render-extractability` | Can a machine read what is there? | D09–D15 |
| `structured-data-audit` | Can it lift out a clean, attributable fact? | D16–D21 |
| `entity-corroboration` | Is that fact attached to the right entity, and believed? | D22–D27 |
| `engagement-audit` | Does the visitor who arrives stay? | E01–E13 |

## How the entrypoint composes them

1. **Normalise** the target and resolve the real host, treating `host` and
   `www.host` as one site.
2. **Crawl once.** `fetch_bundle.py` performs the only network pass and writes
   `bundle.json`: sampled pages with raw HTML, rendered DOM, JS-disabled DOM,
   headers, redirect hops, transfer weight, plus `robots.txt` and sitemap data.
   Every diagnostic skill reads that bundle instead of re-fetching, which keeps the
   run under five minutes and the site's load to one polite pass.
3. **Delegate** to the five diagnostic skills, each returning raw check records.
4. **Reconcile.** Suppression rules fold consequential failures into their root
   cause rather than reporting them side by side.
5. **Assemble.** Severity is assigned from the check definition, findings are sorted
   and numbered deterministically, proactive recommendations are added, and one
   report is emitted.

## Why reconciliation matters

Checks are not independent. A site that renders entirely client-side will trip the
h1 check, the meta description check, the heading hierarchy check, the JSON-LD
check and the canonical check — all because of one root cause. Reporting those as
five findings sends the reader to fix the wrong five things.

The orchestrator re-evaluates raw-HTML-derived checks against the rendered DOM. A
check that passes there becomes a `consequence` of the render gap; one that fails
there is a genuine independent finding. Nothing observed is discarded — it moves
under the finding that explains it.

The same principle covers absence (no sitemap must not also fire as stale sitemap
dates), site type (a pricing check at a reference site is a false positive), and
proactive items (a missing `llms.txt` is an opportunity, never a defect).

## Report shape

Meets the required floor — `site`, `audited_at`, severity counts, and per-finding
`id`, `title`, `severity`, `evidence`, `suggested_action` — and extends it with
`check_id`, `mechanism`, `consequences`, `suggested_action.detail` / `.effort` /
`.verify`, `proactive_actions`, and a `coverage` block that distinguishes "checked
and clean" from "never checked".

Full schema and a worked example: `skills/audit-orchestrator/references/report-schema.md`.

## Evidence standard

Every finding cites a reproducible observation — a count, a URL, a header value, a
quoted line from `robots.txt`. "Poor structured data" is not evidence. "0 of 12
sampled product pages contain `<script type=application/ld+json>`" is.

Each finding also carries a `mechanism`: one sentence on *why* the defect stops an
assistant, not merely that it is wrong. That is what separates an audit from a
linter.

## Checks that need judgement

Thirty-four of the forty-one checks are decided by script. Seven are not, and the
marketplace is explicit about which:

| Check | Why it needs judgement |
| --- | --- |
| `D12`, `D13` | Whether a fact is *missing* or merely *not published* needs a human read |
| `E01`, `E02` | Whether copy states the offering is a reading task, not a pattern match |
| `D22`, `D25`, `D27` | Require live search against the wider web |

For these the script emits the evidence and marks the check `unclear` rather than
guessing. `entity-corroboration` additionally writes `entity-research-tasks.json`
naming the exact searches to run and the threshold to apply, so the agent's judgement
is bounded rather than free-form.

An `unclear` result never becomes a finding. It appears in `coverage.unclear`, so a
reader can always tell "checked and clean" from "not established".

## A limit the audit states rather than hides

A site can pass every check here and still lose unbranded category queries to
comparison and listicle content. That is a property of how category queries get
answered, not a site defect, and `entity-corroboration` is explicit that it must not
be reported as one. Where the gap is category association rather than site quality,
the recommendation is off-site and says so.

## Guardrails

- Recommend-only; no writes, no form submissions, no authenticated requests.
- `robots.txt` respected; one request per second; `sample_size` caps total fetches.
- Portable: standard Agent Skills format, no external service needed to resolve the manifest.
- Deterministic: the same site and sample produces the same findings, severities and IDs.
