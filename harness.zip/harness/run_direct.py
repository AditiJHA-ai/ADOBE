import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent / "brand-ai-readiness-audit"
S = ROOT / "skills"
STAGES = [
    ("crawl-access-audit", "check_access.py", "access.json"),
    ("render-extractability", "check_render.py", "render.json"),
    ("structured-data-audit", "check_schema.py", "schema.json"),
    ("entity-corroboration", "check_entity.py", "entity.json"),
    ("engagement-audit", "check_engagement.py", "engagement.json"),
]


def sh(args, cwd):
    p = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True, text=True)
    if p.returncode:
        print(p.stdout, p.stderr, file=sys.stderr)
        raise SystemExit(f"failed: {' '.join(args)}")
    return p.stdout


def main(site):
    out = pathlib.Path("runs") / site.replace("/", "_").replace(":", "")
    out.mkdir(parents=True, exist_ok=True)
    print(sh([str(S / "audit-orchestrator/scripts/fetch_bundle.py"), site,
              "--out", "bundle.json", "--sample", "10"], out))
    findings = []
    for skill, script, name in STAGES:
        args = [str(S / skill / "scripts" / script), "--bundle", "bundle.json", "--out", name]
        if skill == "entity-corroboration":
            args += ["--tasks", "research-tasks.json"]
        print(f"--- {skill}"); print(sh(args, out))
        findings.append(name)
    sh([str(S / "audit-orchestrator/scripts/assemble_report.py"), "--findings", *findings,
        "--bundle", "bundle.json", "--out", "report.json"], out)
    r = json.loads((out / "report.json").read_text())
    print(json.dumps(r["summary"], indent=2))
    for f in r["findings"]:
        print(f"  {f['id']} {f['check_id']:4s} {f['severity']:8s} {f['title']}")
    cv = r["coverage"]
    print(f"\ncoverage: {cv['status']} | {cv['checks_passed']}/{cv['checks_run']} passed | "
          f"{len(cv['unclear'])} unclear | {len(cv['not_applicable'])} n/a")
    print(f"report: {out/'report.json'}")


if __name__ == "__main__":
    main(sys.argv[1])
