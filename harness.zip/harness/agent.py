import json
import pathlib
import subprocess
import sys

from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.skills import load_skills_from_dir
from google.adk.tools.skill_toolset import SkillToolset

MARKETPLACE = pathlib.Path(__file__).resolve().parent.parent / "brand-ai-readiness-audit"
SKILLS_DIR = MARKETPLACE / "skills"
WORKDIR = pathlib.Path(__file__).resolve().parent / "runs"
WORKDIR.mkdir(exist_ok=True)

# audit-orchestrator's own procedure: one shared crawl, then each diagnostic
# skill's script against it. None of these steps need an LLM — they're
# deterministic scripts — so running them as one Python call instead of
# having the agent invoke each one turn-by-turn cuts a ~15-call conversation
# down to ~2 (call this tool, then narrate the result). That's what keeps a
# full audit inside a tight demo window instead of one call per skill.
STAGES = [
    ("crawl-access-audit", "check_access.py", "access.json"),
    ("render-extractability", "check_render.py", "render.json"),
    ("structured-data-audit", "check_schema.py", "schema.json"),
    ("entity-corroboration", "check_entity.py", "entity.json"),
    ("engagement-audit", "check_engagement.py", "engagement.json"),
]


def _run_script(args: list, cwd: pathlib.Path) -> str:
    p = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True,
                       text=True, timeout=180)
    if p.returncode:
        raise RuntimeError(f"{pathlib.Path(args[0]).name} failed: {p.stderr[-2000:]}")
    return p.stdout


def run_full_audit(url: str, sample_size: int = 10) -> dict:
    """Run the complete brand AI-readiness audit in one step.

    Executes audit-orchestrator's procedure end to end: one shared crawl, all
    five diagnostic skills against it, then report assembly. Use this instead
    of manually loading each skill and running its script one at a time — for
    an actual audit run, call this once rather than driving the pipeline
    step by step.

    Args:
        url: Site URL or bare domain to audit.
        sample_size: Number of pages to sample. Defaults to 10.

    Returns:
        A dict with `report` (the parsed report.json) and `report_path`, or
        `error` if a stage failed.
    """
    out = WORKDIR / url.replace("://", "_").replace("/", "_").replace(":", "")
    out.mkdir(parents=True, exist_ok=True)

    try:
        _run_script([str(SKILLS_DIR / "audit-orchestrator/scripts/fetch_bundle.py"), url,
                     "--out", "bundle.json", "--sample", str(sample_size)], out)

        findings = []
        for skill, script, name in STAGES:
            args = [str(SKILLS_DIR / skill / "scripts" / script), "--bundle", "bundle.json", "--out", name]
            if skill == "entity-corroboration":
                args += ["--tasks", "research-tasks.json"]
            _run_script(args, out)
            findings.append(name)

        _run_script([str(SKILLS_DIR / "audit-orchestrator/scripts/assemble_report.py"),
                     "--findings", *findings, "--bundle", "bundle.json", "--out", "report.json"], out)
    except RuntimeError as e:
        return {"error": str(e)}

    report = json.loads((out / "report.json").read_text())
    return {"report": report, "report_path": str(out / "report.json")}


def read_json(path: str) -> dict:
    """Read a JSON or text file produced by an audit run.

    Args:
        path: Path relative to the audit working directory.

    Returns:
        A dict with the file's text content, truncated to 4000 characters.
    """
    f = WORKDIR / path
    if not f.exists():
        return {"error": f"{path} does not exist"}
    return {"content": f.read_text()[:4000]}


skills = load_skills_from_dir(SKILLS_DIR)

root_agent = LlmAgent(
    name="audit_harness",
    model=LiteLlm(
        model="groq/qwen/qwen3.8-27b",
        reasoning_effort="none",
        num_retries=3,
        retry_strategy="exponential_backoff_retry",
    ),
    instruction=(
        "To audit a website, call `run_full_audit(url)` once — it runs the "
        "entire audit-orchestrator procedure (crawl, all five diagnostic "
        "skills, report assembly) in a single step. Do not manually load "
        "skills or run their scripts one at a time for an audit; that path "
        "exists only for explaining how a specific check works if asked.\n\n"
        "After `run_full_audit` returns, state where report.json was "
        "written and summarise the findings by severity. Do not invent "
        "findings beyond what the report contains — a check marked "
        "`unclear` stays unclear.\n\n"
        "If asked how a particular check or skill works, use `list_skills` "
        "and `load_skill` to answer from the actual skill definitions."
    ),
    tools=[
        run_full_audit,
        SkillToolset(
            skills=skills,
            tool_filter=["list_skills", "load_skill", "load_skill_resource"],
        ),
        read_json,
    ],
)
